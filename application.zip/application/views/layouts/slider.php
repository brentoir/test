<!-- Slider desktop tablets -->
<div id="carouselExampleControls" class="carousel slide hidden-md-down" data-ride="carousel">
  <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/slider01.jpg') ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/slider02.jpg') ?>" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/slider03.jpg') ?>" alt="Third slide">
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/slider04.jpg') ?>" alt="Fourth slide">
    </div>
  </div>

  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- end slider Desktop tablets -->

<!-- Slider Mobile -->
<!-- <div id="carousel-md" class="carousel slide d-none d-md-block d-lg-none" data-ride="carousel">
  <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/img1.jpg') ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/img2.jpg') ?>" alt="Second slide">
<div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/img3.jpg') ?>" alt="Third slide">
    </div>
<div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/img4.jpg') ?>" alt="Fourth slide">
    </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carousel-md" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel-md" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div> -->
<!-- end slider Mobile -->


<!-- Slider Mobile -->
<div id="carousel-mobile" class="carousel slide hidden-lg-up" data-ride="carousel">
  <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/mobile/img1.jpg') ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/mobile/img2.jpg') ?>" alt="Second slide">
    </div>
         <div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/mobile/img3.jpg') ?>" alt="Third slide">
    </div>
      <div class="carousel-item">
      <img class="d-block img-fluid" src="<?php echo base_url('assets/img/slide/mobile/img4.jpg') ?>" alt="Fourth slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carousel-mobile" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel-mobile" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- end slider Mobile -->