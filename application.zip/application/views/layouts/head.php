<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from htmlstream.com/preview/unify-v2.1/e-commerce/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Aug 2017 23:26:21 GMT -->
<head>
    <!-- Title -->
    <title>Electrobras SRL</title>

    <!-- Required Meta Tags Always Come First -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Favicon -->
    <link rel="shortcut icon" href="">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href="<?php echo base_url('/assets/vendor/bootstrap/bootstrap.min.css');?>">

    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/icon-line/css/simple-line-icons.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/icon-hs/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/icon-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/icon-line-pro/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/icon-etlinefont/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/slick-carousel/slick/slick.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/animate.css">
    <link rel="stylesheet" href="<?php echo base_url('/assets/vendor/cubeportfolio-full/cubeportfolio/css/cubeportfolio.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/hamburgers/hamburgers.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/hs-megamenu/src/hs.megamenu.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/malihu-scrollbar/jquery.mCustomScrollbar.min.css">
    <link  rel="stylesheet" href="<?php echo base_url();?>assets/vendor/fancybox/jquery.fancybox.min.css">
    <link  rel="stylesheet" href="<?php echo base_url();?>assets/vendor/datatables/datatables.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/vendor/noty/noty.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/vendor/noty/theme/bootstrap-v4.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-tags-input/tagsinput.css');?>">

    <!-- Revolution Slider -->
<!--     <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/css/settings.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/css/layers.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/css/navigation.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution-addons/typewriter/css/typewriter.css"> -->

    <!-- CSS Unify Theme -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/styles.e-commerce.css">

    <!-- CSS Customization -->
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/custom.css">
    <!-- JS -->
    <script src="<?php echo base_url('/assets/vendor/jquery/jquery.min.js');?>"></script>
  </head>