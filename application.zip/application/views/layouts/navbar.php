<body>
    <main>
      <!-- Header -->
      <header id="js-header" class="u-header u-header--static">
        <!-- Top Bar -->
        <div class="u-header__section u-header__section--dark g-bg-black g-transition-0_3 g-py-10">
          <div class="container">
            <div class="row flex-column flex-sm-row justify-content-between align-items-center text-uppercase g-font-weight-600 g-color-white g-font-size-12 g-mx-0--lg">
              <div class="col-auto">
                <ul class="list-inline mb-0">
                  <li class="list-inline-item">
                    <a href="https://www.facebook.com/ELECTROBRAScomodoro/" class="g-color-white g-color-indigo--hover g-pa-3" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                  </li>
                  <li class="list-inline-item">
                    <i class="fa fa-facebook-messenger"></i>
                  </li>
                  <li class="list-inline-item">
                    <a href="https://wa.me/542974248436?text=Envianos%20tu%20consulta" class="g-color-white g-color-indigo--hover g-pa-3" title="Whatsapp"><i class="fa fa-whatsapp"></i></a>
                  </li>
                </ul>
              </div>

              <div class="col-auto g-pb-10 g-pb-0--sm">
                <i class="fa fa-phone g-font-size-18 g-valign-middle g-color-indigo g-mr-10 g-mt-minus-2"></i> 0297 4460636
              </div>

              <div class="col-auto hidden-md-down">
                <i class="fa fa-clock-o g-font-size-18 g-valign-middle g-color-indigo g-mr-10 g-mt-minus-2"></i> Lun-Vier: 9 a 12 / 15:30 a 20:15 - Sab: 9 a 13
              </div>
            </div>
          </div>
        </div>
        <!-- End Top Bar -->
        <div class="u-header__section u-header__section--light g-bg-white g-transition-0_3 g-py-10">
          <nav class="js-mega-menu navbar navbar-toggleable-md">
         <div class="container">
            <!-- Responsive Toggle Button -->
            <button class="navbar-toggler navbar-toggler-right btn g-line-height-1 g-brd-none g-pa-0 g-pos-abs g-right-0" type="button"
                    aria-label="Toggle navigation"
                    aria-expanded="false"
                    aria-controls="navBar"
                    data-toggle="collapse"
                    data-target="#navBar">
              <span class="hamburger hamburger--slider">
                <span class="hamburger-box">
                  <span class="hamburger-inner"></span>
                </span>
              </span>
            </button>
            <!-- End Responsive Toggle Button -->

            <!-- Logo -->
            <a href="<?php echo base_url();?>" class="navbar-brand">
              <img src="<?php echo base_url('assets/img/logo/logo.png');?>" alt="Image Description">
            </a>
            <!-- End Logo -->

            <!-- Navigation -->
            <div class="collapse navbar-collapse align-items-center flex-sm-row g-pt-10 g-pt-5--lg" id="navBar">
              <ul class="navbar-nav ml-auto text-uppercase g-font-weight-600 u-main-nav-v7 u-sub-menu-v1">
                <li class="nav-item g-mx-2--md g-mx-5--xl g-mb-5 g-mb-0--lg <?php echo $is_active['inicio'] ?>">
                  <a href="<?php echo base_url('');?>" class="nav-link">Inicio</a>
                </li>
                <li class="nav-item g-mx-2--md g-mx-5--xl g-mb-5 g-mb-0--lg <?php echo $is_active['empresa'] ?>">
                  <a href="<?php echo base_url('index.php/Electrobras/Empresa');?>" class="nav-link">Empresa</a>
                </li>
                <li class="nav-item hs-has-sub-menu g-mx-2--md g-mx-5--xl g-mb-5 g-mb-0--lg <?php echo $is_active['productos'] ?>">
                  <a href="#" class="nav-link" id="nav-link-1"
                    aria-haspopup="true"
                    aria-expanded="false"
                    aria-controls="nav-submenu-1">
                    Productos</a>
                  <!-- Submenu -->
                  <ul class="hs-sub-menu list-unstyled g-mt-17--lg g-mt-7--lg--scrolling" id="nav-submenu-1"
                      aria-labelledby="nav-link-1">
                    <li><a href="<?php echo base_url('index.php/Electrobras/Electricidad');?>">Electricidad</a></li>
                    <li><a href="<?php echo base_url('index.php/Electrobras/Iluminacion');?>">Iluminacion</a></li>
                    <li><a href="<?php echo base_url('index.php/Galeria');?>">Imágenes</a></li>
                  </ul>
                  <!-- End Submenu -->
                </li>
                <li class="nav-item g-mx-2--md g-mx-5--xl g-mb-5 g-mb-0--lg <?php echo $is_active['novedades'] ?>">
                  <a href="<?php echo base_url('index.php/Novedades');?>" class="nav-link">Novedades</a>
                </li>
                <li class="nav-item g-mx-2--md g-mx-5--xl g-mb-5 g-mb-0--lg <?php echo $is_active['contacto'] ?>">
                  <a href="<?php echo base_url('index.php/Electrobras/Contacto');?>" class="nav-link">Contacto</a>
                </li>
                <li class="nav-item g-mx-2--md g-mx-5--xl g-mb-5 g-mb-0--lg <?php echo $is_active['newsletter'] ?>">
                  <a href="<?php echo base_url('index.php/Newsletter');?>" class="nav-link">Newsletter</a>
                </li>
              </ul>
            </div>
            <!-- End Navigation -->
          </div>
          </nav>
        </div>
      </header>
      <!-- End Header -->