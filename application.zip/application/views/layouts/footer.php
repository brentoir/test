
<!-- Footer -->
<footer class="g-bg-blue-radialgradient-circle g-color-white-opacity-0_8 g-bg-img-hero g-pt-60">
  <div class="container g-mb-60">
    <div class="row">
      <!-- Footer Content -->
      <div class="col-lg-4 col-md-6 g-mb-40 g-mb-0--lg">
        <div class="u-heading-v2-3--bottom g-brd-white-opacity-0_8 g-mb-20">
          <h2 class="u-heading-v2__title h6 text-uppercase mb-0">Newsletter</h2>
        </div>
        <div class="g-mb-30 ">
          <form id="form_subscribirse" class="mb-2">
            <input id="newsletter_name" name="newsletter_name" 
                   class="form-control u-form-control rounded-0 col-sm-8 mb-2" type="text"  value=""
                   placeholder="Nombre" required>
            
            <input id="newsletter_email" name="newsletter_email" 
                         class="form-control u-form-control rounded-0 col-sm-8 mb-2" type="email"  value=""
                         placeholder="Correo" required>
            <button type="submit" class="btn u-btn-black u-btn-inset u-btn-inset"> Suscribirse </button>
          </form>
           

          <h6>Suscribite para recibir nuestras novedades y promociones en tu correo.</h6>
        </div>

      </div>
      <!-- End Footer Content -->

      <!-- Footer Content -->
      <div class="col-lg-4 col-md-6 g-mb-40 g-mb-0--lg">

        <div class="u-heading-v2-3--bottom g-brd-white-opacity-0_8 g-mb-20">
          <h2 class="u-heading-v2__title h6 text-uppercase mb-0">Contacto:</h2>
        </div>

        <ul class="list-unstyled">
          <li class="g-mb-5">
            <i class="fa fa-envelope-open-o"></i>
            <a class="g-color-white-opacity-0_8" href="mailto:info@electrobrassrl.com.ar">info@electrobrassrl.com.ar</a>
          </li>
          <li>
            <i class="fa fa-phone"> 0297 4460636</i>
          </li>
          <li>
            <i class="fa fa-fax"> 0297 4463786</i>
          </li>
          <li>
            <i class="fa fa-map-marker"> Alem 657 - Comodoro Rivadavia - Chubut</i>
          </li>
          <li>
            <i class="fa fa-clock-o"> Lun a Vier de 9 a 12:00 hs. y de 15:30 a 20:15 hs. Sáb de 9 a 13 hs.</i>
          </li>
        </ul>
      </div>
      <!-- End Footer Content -->

      <!-- Footer Content -->
      <div class="col-lg-4 col-md-6 g-mb-40 g-mb-0--lg">

        <div class="u-heading-v2-3--bottom g-brd-white-opacity-0_8 g-mb-20">
          <h2 class="u-heading-v2__title h6 text-uppercase mb-0">Seguinos:</h2>
        </div>

        <ul class="list-unstyled">
          <li class="g-mb-5">
              <a class="u-icon-v3 u-icon-size--sm g-bg-facebook g-color-white g-color-white--hover g-mr-15 g-mb-20" href="https://www.facebook.com/ELECTROBRAScomodoro/" target="_blank"><i class="fa fa-facebook"></i></a>
          </li>
        </ul>
      </div>
      <!-- End Footer Content -->
    </div>
  </div>

  <!-- Copyright -->
  <div class="container g-pt-10 g-pb-10">
    <div class="row justify-content-between align-items-center">
      <div class="col-md-6 g-mb-20">
        <p class="g-font-size-13 mb-0 g-color-black"><?php echo date('Y') ?> © Brenda Solari. Todos los derechos reservados.</p>
      </div>

      <div class="col-md-6 text-md-right g-mb-20">
        <ul class="list-inline g-color-black g-font-size-25 mb-0">
          <li class="list-inline-item g-cursor-pointer mr-1">
            <i class="fa fa-cc-visa" title="Visa"
               data-toggle="tooltip"
               data-placement="top"></i>
          </li>
          <li class="list-inline-item g-cursor-pointer mx-1">
            <i class="fa fa-cc-mastercard" title="Master Card"
               data-toggle="tooltip"
               data-placement="top"></i>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <!-- End Copyright -->
</footer>
<!-- End Footer -->
                

      <a class="js-go-to u-go-to-v2" href="#"
         data-type="fixed"
         data-position='{
           "bottom": 15,
           "right": 15
         }'
         data-offset-top="400"
         data-compensation="#js-header"
         data-show-effect="zoomIn">
        <i class="hs-icon hs-icon-arrow-top"></i>
      </a>
    </main>

    <!-- JS Global Compulsory -->
    <script src="<?php echo base_url();?>/assets/vendor/jquery-migrate/jquery-migrate.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/tether.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/bootstrap/bootstrap.min.js"></script>

    <!-- JS Implementing Plugins -->
    <script src="<?php echo base_url();?>/assets/vendor/jquery.countdown.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/slick-carousel/slick/slick.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/hs-megamenu/src/hs.megamenu.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/malihu-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script  src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/cubeportfolio-full/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
    <script src="<?php echo base_url('assets/vendor/noty/noty.min.js');?>"></script>
    <script src="<?php echo base_url('assets/vendor/jquery-validate/jquery.validate.min.js');?>"></script>
    <script src="<?php echo base_url('assets/vendor/jquery-validate/additional-methods.min.js');?>"></script>
    <script src="<?php echo base_url('assets/vendor/jquery-validate/messages_es_AR.min.js');?>"></script>
    <script src="<?php echo base_url('assets/vendor/bootstrap-tags-input/tagsinput.js');?>"></script>




    <!-- JS Revolution Slider -->
<!--     <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/jquery.themepunch.revolution.min.js"></script>

    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution-addons/typewriter/js/revolution.addon.typewriter.min.js"></script>

    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="<?php echo base_url();?>/assets/vendor/revolution-slider/revolution/js/extensions/revolution.extension.video.min.js"></script>
 -->
    <!-- JS Unify -->
    <script src="<?php echo base_url();?>/assets/js/hs.core.js"></script>
    <script src="<?php echo base_url();?>/assets/js/components/hs.header.js"></script>
    <script src="<?php echo base_url();?>/assets/js/helpers/hs.hamburgers.js"></script>
    <script src="<?php echo base_url();?>/assets/js/components/hs.dropdown.js"></script>
    <script src=" <?php echo base_url()?>/assets/js/components/hs.tabs.js"></script>
    <script src="<?php echo base_url();?>/assets/js/components/hs.scrollbar.js"></script>
    <script src="<?php echo base_url();?>/assets/js/components/hs.countdown.js"></script>
    <script src="<?php echo base_url();?>/assets/js/components/hs.carousel.js"></script>
    <script src="<?php echo base_url();?>/assets/js/components/hs.go-to.js"></script>
    <script src="<?php echo base_url();?>/assets/js/components/hs.cubeportfolio.js"></script>
    <script  src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>
   
    <!-- JS Customization -->
    <script src="<?php echo base_url();?>/assets/js/custom.js"></script>

    <!-- JS Implementing Plugins -->
    <script  src="<?php echo base_url();?>/assets/vendor/fancybox/jquery.fancybox.min.js"></script>
    <script  src="<?php echo base_url('assets/vendor/datatables/datatables.min.js');?>"></script>

    <!-- JS Unify -->
    <script  src="<?php echo base_url();?>/assets/js/components/hs.popup.js"></script>

    <!-- JS Plugins Init. -->
    <script >
    // initialization of google map
    function initMap() {
      $.HSCore.components.HSGMap.init('.js-g-map')
    }
    </script>


  <script>
    

    $('#form_subscribirse').submit(function(e){
      e.preventDefault()

      email_disponible( $('#newsletter_email').val() )
    })

    function email_disponible( email )
    {
      $.ajax({
          url: "<?php echo base_url('index.php/Newsletter/check_email');?>",
          type: 'POST',
          cache: false,
          async: false,
          data: { email: email },
          success: function(msg){
            if ( msg == 'disponible' ) {
              registrar_email()
            } else {
              noty_alert('error', 'Este mail ya se encuentra registrado')
            }
          },
          error: function(jqXHR, textStatus, errorThrown){
            noty_alert( 'error' , 'Ocurrio un error en el registro' )
          }
        })
    }

    function registrar_email()
    {
      $.ajax({
          url: "<?php echo base_url('index.php/Newsletter/new_email');?>",
          type: 'POST',
          cache: false,
          data: { name: $('#newsletter_name').val(), email: $('#newsletter_email').val() },
          success: function(msg){
            if (msg === 'success') {
              $('#form_subscribirse')[0].reset()
              noty_alert( 'success' , 'Registro exitoso' )
            } else {
              noty_alert( 'error' , 'No se pudo registrar el correo' )
            }
          },
          error: function(jqXHR, textStatus, errorThrown){
            noty_alert( 'error' , 'No se pudo registrar el correo' )
          }
        })
    } 

    $(document).on('ready', function () {
      // initialization of popups
      $.HSCore.components.HSPopup.init('.js-fancybox');

      // initialization of carousel
      $.HSCore.components.HSCarousel.init('.js-carousel');

      // form
      // $.HSCore.components.HSFileAttachment.init('.js-file-attachment');

      // initialization of tabs galeria imagenes
        $.HSCore.components.HSTabs.init('[role="tablist"]');
    });

    // initialization of HSDropdown component
    $.HSCore.components.HSDropdown.init($('[data-dropdown-target]'), {
      afterOpen: function () {
        $(this).find('input[type="search"]').focus();
      }
    });

    // initialization of go to
    $.HSCore.components.HSGoTo.init('.js-go-to');


    $(window).on('load', function() {
      // initialization of HSScrollBar component
      $.HSCore.components.HSScrollBar.init($('.js-scrollbar'));

      // initialization of header
      $.HSCore.components.HSHeader.init($('#js-header'));
      $.HSCore.helpers.HSHamburgers.init('.hamburger');

      // initialization of HSMegaMenu component
      $('.js-mega-menu').HSMegaMenu({
        event: 'hover',
        pageContainer: $('.container'),
        breakpoint: 991
      });

      // initialization of cubeportfolio
      $.HSCore.components.HSCubeportfolio.init('.cbp');
    });

    $(window).on('resize', function () {
      setTimeout(function () {
        $.HSCore.components.HSTabs.init('[role="tablist"]');
      }, 200);
    });
  </script>


  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAUupX2V6WfloENRmJqg-1Gl-bXEwdw3hY&callback=initMap"
  type="text/javascript"></script>

  </body>
</html>