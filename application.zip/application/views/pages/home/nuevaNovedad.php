<div class="container">
	<h1>Llene el siguiente formulario para subir una novedad</h1>
	<form action="" class="g-brd-around g-brd-gray-light-v4 g-pa-30 g-mb-30">
		<div class="form-group g-mb-20">
		  <!-- Textarea Input with Left Appended Icon -->
		  <div class="form-group g-mb-20">
		    <label class="g-mb-10">Ingrese el texto a subir</label>
		    <div class="input-group g-brd-primary--focus">
		      <div class="input-group-addon d-flex align-items-center g-bg-white g-color-gray-light-v1 rounded-0 g-py-12">
		        <i class="icon-user"></i>
		      </div>
		      <textarea class="form-control form-control-md g-resize-none rounded-0" rows="4" placeholder="Ingrese un texto para la novedad"></textarea>
		    </div>
		  </div>
		  <!-- End Textarea Input with Left Appended Icon -->
		  <!-- Plain File Input -->
		  <div class="form-group mb-0">
		    <p>Click para subir imagen</p>
		    <label class="u-file-attach-v2 g-color-gray-dark-v5 mb-0">
		      <input id="fileAttachment" name="file-attachment" type="file">
		      <i class="icon-cloud-upload g-font-size-16 g-pos-rel g-top-2 g-mr-5"></i>
		      <span class="js-value">Subir imagen</span>
		    </label>
		  </div>
		  <!-- End Plain File Input -->
		</div>
		<a href="#" class="btn btn-md u-btn-inset u-btn-indigo g-mr-10 g-mb-15">Subir novedad</a>

		<a href="<?php echo base_url();?>" class="btn btn-md u-btn-inset u-btn-red g-mr-10 g-mb-15">Cancelar</a>
	</form>
</div>