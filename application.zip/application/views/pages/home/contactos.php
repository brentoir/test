      <!-- Google Map -->
<div id="GMapCustomized-dark" class="js-g-map embed-responsive embed-responsive-21by9 g-height-400"
     data-type="custom"
     data-type="custom"
     data-lat="-45.863946"
     data-lng="-67.498810"
     data-zoom="18"
     data-title="Electrobras SRL"
     data-styles='[
       ["", "", [{"saturation":-100},{"lightness":50},{"visibility":"simplified"}]],
       ["", "geometry", [{"color":"#1e303d"}]],
       ["road", "", [{"color":"#ffffff"},{"lightness":-100}]],
       ["road", "labels.text.fill", [{"color":"#ffffff"},{"lightness":-50}]],
       ["water", "", [{"color":"#0e171d"}]]
     ]'
     data-pin="true"
     data-pin-icon="<?php echo base_url();?>/assets/img/icons/pin/red.png">
       
</div>
      <!-- End Google Map -->
              

      <section class="container g-pt-100 g-pb-40">
        <div class="row justify-content-between">
          <div class="col-md-7 g-mb-60">
            <!-- Contact Form -->
            <form id="form_contacto" action="<?php echo base_url('index.php/Electrobras/send_mail') ?>" method="POST">
              <div class="row">
                <div class="col-md-6 form-group g-mb-20">
                  <label class="g-color-gray-dark-v2 g-font-size-13">Nombre:</label>
                  <input id="nombre" name="nombre" class="form-control g-color-gray-dark-v5 g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--focus rounded-3 g-py-13 g-px-15" type="text">
                </div>

                <div class="col-md-6 form-group g-mb-20">
                  <label class="g-color-gray-dark-v2 g-font-size-13">Correo:</label>
                  <input id="email" name="email" class="form-control g-color-gray-dark-v5 g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--focus rounded-3 g-py-13 g-px-15" type="email">
                </div>

                <div class="col-md-6 form-group g-mb-20">
                  <label class="g-color-gray-dark-v2 g-font-size-13">Asunto:</label>
                  <input id="asunto" name="asunto" class="form-control g-color-gray-dark-v5 g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--focus rounded-3 g-py-13 g-px-15" type="text">
                </div>

                <div class="col-md-6 form-group g-mb-20">
                  <label class="g-color-gray-dark-v2 g-font-size-13">Telefono:</label>
                  <input id="telefono" name="telefono" class="form-control g-color-gray-dark-v5 g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--focus rounded-3 g-py-13 g-px-15" type="tel">
                </div>

                <div class="col-md-12 form-group g-mb-40">
                  <label class="g-color-gray-dark-v2 g-font-size-13">Mensaje:</label>
                  <textarea id="mensaje" name="mensaje" class="form-control g-color-gray-dark-v5 g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--focus g-resize-none rounded-3 g-py-13 g-px-15" rows="7"></textarea>
                </div>
              </div>

              <button class="btn u-btn-indigo rounded-3 g-py-12 g-px-20" type="submit" role="button">Enviar</button>
            </form>
            <!-- End Contact Form -->
          </div>

          <div class="col-md-4">
            <h1 class="g-font-weight-300 mb-5">Electrobras SRL</h1>

            <div class="mb-4">
              <h2 class="h5 g-color-gray-dark-v2 g-font-weight-600">Direccion:</h2>
              <p class="g-color-gray-dark-v4 g-font-size-16">Alem 657<br>Comodoro Rivadavia<br>Chubut<br>Argentina</p>
            </div>

            <div class="mb-4">
              <h2 class="h5 g-color-gray-dark-v2 g-font-weight-600">Consultas:</h2>
              <p class="g-color-gray-dark-v4">Email: <a class="g-color-gray-dark-v2" href="#">administracion@electrobrassrl.com.ar</a></p>
              <p class="g-color-gray-dark-v4">Telefono: <span class="g-color-gray-dark-v2">0297 4460636</span></p>
            </div>

            <div class="g-mb-30">
              <p class="g-color-gray-dark-v5 g-font-weight-600 g-font-size-16"><em> LUN-VIER: 9 A 12 / 15:30 A 20:15 - SAB: 9 A 13</em></p>
            </div>

            <!-- Figure Social Icons -->
            <ul class="list-inline">
              <li class="list-inline-item">
                <a class="u-icon-v1 g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover rounded-circle" href="#">
                  <i class="g-font-size-default fa fa-facebook"></i>
                </a>
              </li>
            </ul>
            <!-- End Figure Social Icons -->
          </div>
        </div>
      </section>


