  <!-- About -->
    <div class="row">
      <!-- img local XL -->
      <div class="col-xl-4 hidden-lg-down g-mb-30 text-center">
        <a class="js-fancybox" href="<?php echo base_url('assets/img/local.png');?>" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-fancybox-speed="1000" data-fancybox-blur-bg="blur" data-fancybox-bg="rgba(0,0,0, 1)">
          <img class="img-fluid w-80 p-3" src="<?php echo base_url('assets/img/localSmall.png');?>" alt="Image Description">
        </a>
      </div>
      <!-- img local lg o menor -->
      <div class="col-lg-12 col-md-12 col-sm-12 hidden-xl-up g-mb-30 text-center">
        <a class="js-fancybox" href="<?php echo base_url('assets/img/local.png');?>" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-fancybox-speed="1000" data-fancybox-blur-bg="blur" data-fancybox-bg="rgba(0,0,0, 1)">
          <img class="img-fluid" src="<?php echo base_url('assets/img/localSmall.png');?>" alt="Image Description">
        </a>
      </div>
      <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 u-shadow-v1-5 g-line-height-2 g-pa-40 g-mb-30" role="alert">
        <h3 class="h2 g-font-weight-300 g-mb-20">Electrobras SRL</h3>
        <p class="mb-0">Somos una empresa líder de la Patagonia para la Patagonia dedicada a la venta de electricidad e iluminación para el hogar, comercio, e industria. Con una trayectoria de 25 años en el mercado.
      Nuestro local totalmente remodelado cuenta con una superficie real de 900 mts2 de exposición y venta. Un depósito en dos niveles de 350 mts2 con permanente stock. 
      Personal capacitado e idóneo para asesorar a quien lo requiera, una excelente atención personalizada. Incorporamos a nuestra línea de ventas Petit muebles, sillas, sillones, mesas, modulares y muchos productos mas para lograr ese toque de distinción que tanto buscaba.
        </p>
      </div>
    </div>
  <!-- end About -->