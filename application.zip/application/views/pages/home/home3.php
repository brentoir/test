<!-- Features -->
<div class="g-brd-bottom g-brd-gray-light-v4">
  <div class="container g-py-30">
    <div class="row justify-content-center">
      <div class="col-md-4 mx-auto g-py-15">
        <div class="media g-px-50--lg">
          <i class="d-flex g-color-black g-font-size-30 g-pos-rel g-top-3 mr-4 icon-finance-232 u-line-icon-pro"></i>
          <div class="media-body">
            <span class="d-block g-font-weight-400 g-font-size-default text-uppercase">El mejor precio</span>
            <span class="d-block g-color-gray-dark-v4">Siempre las mejores ofertas para cuidar su bolsillo</span>
          </div>
        </div>
      </div>

      <div class="col-md-4 mx-auto g-brd-x--md g-brd-gray-light-v3 g-py-15">
        <div class="media g-px-50--lg">
          <i class="d-flex g-color-black g-font-size-30 g-pos-rel g-top-3 mr-4 icon-hotel-restaurant-225 u-line-icon-pro"></i>
          <div class="media-body">
            <span class="d-block g-font-weight-400 g-font-size-default text-uppercase">Atencion personalizada</span>
            <span class="d-block g-color-gray-dark-v4">Ejemplo</span>
          </div>
        </div>
      </div>

      <div class="col-md-4 mx-auto g-py-15">
        <div class="media g-px-50--lg">
          <i class="d-flex g-color-black g-font-size-30 g-pos-rel g-top-3 mr-4 icon-hotel-restaurant-062 u-line-icon-pro"></i>
          <div class="media-body text-left">
            <span class="d-block g-font-weight-400 g-font-size-default text-uppercase">Ahorra mas tiempo</span>
            <span class="d-block g-color-gray-dark-v4">Ejemplo</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- End Features -->


    <!-- About -->
    <section class="g-pt-100 g-pb-100">
      <div class="container">
        <!-- Image, Text Block -->
        <div class="row d-flex align-items-lg-center flex-wrap g-mb-60 g-mb-0--lg">
          <div class="col-md-6 col-lg-8">
            <img class="img-fluid rounded" src="<?php echo base_url('assets/img/local.png') ?>" alt="Image Description">
          </div>
          <div class="col-md-6 col-lg-4">
            <div class="g-mt-minus-30 g-mt-0--md g-ml-minus-100--lg">
              <div class="g-mb-20">
                <h2 class="g-color-black g-font-weight-600 g-font-size-25 g-font-size-35--lg g-line-height-1_2 mb-4">Electrobras SRL
                  </h2>
                <p class="g-font-size-16 g-color-black">Somos una empresa líder de la Patagonia para la Patagonia dedicada a la venta de electricidad e iluminación para el hogar, comercio, e industria.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- End Image, Text Block -->
      </div>

      <div class="container">
        <!-- Image, Text Block -->
        <div class="row d-flex justify-content-between align-items-lg-center flex-wrap g-mt-minus-50--lg">
          <div class="col-md-6 order-md-2">
            <div class="g-brd-around--md g-brd-10 g-brd-white rounded">
              <img class="img-fluid w-100 rounded" src="<?php echo base_url('assets/img/example/electro_in_600x450.jpg');?>" alt="Image Description">
            </div>
          </div>
          <div class="col-md-6 col-lg-4 ml-auto order-md-1">
            <div class="g-mt-minus-30 g-mt-0--md g-ml-minus-100--lg">
              <div class="g-mb-20">
                <h2 class="g-color-black g-font-weight-600 g-font-size-25 g-font-size-35--lg g-line-height-1_2 mb-4">Más de 25 años en el mercado
                  </h2>
                <p class="g-font-size-16 g-color-black">This is where we sit down, grab a cup of coffee and dial in the details. Understanding the task at hand and ironing out the wrinkles is key.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- End Image, Text Block -->
      </div>
    </section>
    <!-- End About -->


    <!-- Our Services -->
    <section class="g-py-20">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 g-mb-60 g-mb-0--lg">
            <!-- Icon Blocks -->
            <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
              <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
                  <i class="icon-education-008 u-line-icon-pro "></i>
                </span>
              <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Novedades</h3>
              <p class="g-mb-15">Enterate de novedades, descuentos y nuevos productos.</p>
              <div class="text-center">
                <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase p-3 mt-3" href="<?php echo base_url('index.php/Electrobras/Novedades');?>">Ver nodedades</a>
              </div>
            </div>
            <!-- End Icon Blocks -->
          </div>

          <div class="col-lg-4 g-mb-60 g-mb-0--lg">
            <!-- Icon Blocks -->
            <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
              <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
                  <i class="icon-hotel-restaurant-170 u-line-icon-pro"></i>
                </span>
              <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Nuestro personal</h3>
              <p class="g-mb-15">Personal capacitado e idóneo para asesorar a quien lo requiera, una excelente atención personalizada. </p>
            </div>
            <!-- End Icon Blocks -->
          </div>

          <div class="col-lg-4">
            <!-- Icon Blocks -->
            <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
              <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
                  <i class="icon-electronics-154 u-line-icon-pro"></i>
                </span>
              <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Nuestros productos</h3>
              <p class="g-mb-15">Todos nuestros productos son de primera calidad y al mejor precio, si quiere enterarse de las marcas que ofrecemos dirijase al siguiente link.</p>
              <div class="text-center">
                <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase g-py-12 g-px-25 mt-2" href="<?php echo base_url('index.php/Electrobras/Electricidad');?>">Ver marcas</a>
              </div>
            </div>
            <!-- End Icon Blocks -->
          </div>
        </div>
      </div>
    </section>
    <!-- End Our Services -->

<section class="container-fluid g-py-50">

  <div class="row justify-content-center">
    <div class="col-md-6 col-sm-12 g-mb-30">
      <a class="js-fancybox" href="<?php echo base_url('assets/img/novedades/inicio/thumb/nov01b.jpg');?>" title="Single Image" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-blur-bg="true">
        <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/inicio/thumb/nov01b.jpg');?>" alt="Image Description">
      </a>
    </div>
    <div class="col-md-6 col-sm-12 g-mb-30">
      <a class="js-fancybox" href="<?php echo base_url('assets/img/novedades/inicio/thumb/nov02b.jpg');?>" title="Single Image" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-blur-bg="true">
        <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/inicio/thumb/nov02b.jpg');?>" alt="Image Description">
      </a>
    </div>
  </div>
</section>






                  





 