<!-- Features -->
<div class="g-brd-bottom g-brd-gray-light-v4">
  <div class="container g-py-30">
    <div class="row justify-content-center">
      <div class="col-md-4 mx-auto g-py-15">
        <div class="media g-px-50--lg">
          <i class="d-flex g-color-black g-font-size-30 g-pos-rel g-top-3 mr-4 icon-finance-232 u-line-icon-pro"></i>
          <div class="media-body">
            <span class="d-block g-font-weight-400 g-font-size-default text-uppercase">El mejor precio</span>
            <span class="d-block g-color-gray-dark-v4">Siempre las mejores ofertas para cuidar su bolsillo</span>
          </div>
        </div>
      </div>

      <div class="col-md-4 mx-auto g-brd-x--md g-brd-gray-light-v3 g-py-15">
        <div class="media g-px-50--lg">
          <i class="d-flex g-color-black g-font-size-30 g-pos-rel g-top-3 mr-4 icon-hotel-restaurant-225 u-line-icon-pro"></i>
          <div class="media-body">
            <span class="d-block g-font-weight-400 g-font-size-default text-uppercase">Atencion personalizada</span>
            <span class="d-block g-color-gray-dark-v4">Ejemplo</span>
          </div>
        </div>
      </div>

      <div class="col-md-4 mx-auto g-py-15">
        <div class="media g-px-50--lg">
          <i class="d-flex g-color-black g-font-size-30 g-pos-rel g-top-3 mr-4 icon-hotel-restaurant-062 u-line-icon-pro"></i>
          <div class="media-body text-left">
            <span class="d-block g-font-weight-400 g-font-size-default text-uppercase">Ahorra mas tiempo</span>
            <span class="d-block g-color-gray-dark-v4">Ejemplo</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- End Features -->

<section class="container-fluid g-py-100">

  <!-- About -->
  <div class="row justify-content-center text-center g-mb-50">
    <div class="col-lg-9">
      <h2 class="h3 g-color-black g-font-weight-600 text-uppercase mb-2">Electrobras SRL</h2>
      <div class="d-inline-block g-width-35 g-height-2 g-bg-primary mb-2"></div>
      <p class="lead mb-0">Somos una empresa líder de la Patagonia para la Patagonia dedicada a la venta de electricidad e iluminación para el hogar, comercio, e industria. Con una trayectoria de 25 años en el mercado.</p>
    </div>
  </div>
  <!-- End about -->

  <div class="row justify-content-center">
    <div class="col-md-6 col-sm-12 g-mb-30">
      <a class="js-fancybox" href="<?php echo base_url('assets/img/novedades/inicio/thumb/nov01b.jpg');?>" title="Single Image" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-blur-bg="true">
        <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/inicio/thumb/nov01b.jpg');?>" alt="Image Description">
      </a>
    </div>
    <div class="col-md-6 col-sm-12 g-mb-30">
      <a class="js-fancybox" href="<?php echo base_url('assets/img/novedades/inicio/thumb/nov02b.jpg');?>" title="Single Image" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-blur-bg="true">
        <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/inicio/thumb/nov02b.jpg');?>" alt="Image Description">
      </a>
    </div>
  </div>

<!-- Box Shadow -->
  <div class="row col-sm-12 justify-content-center">
    <div class="u-shadow-v1-5 g-line-height-2 g-pa-30 g-mb-30 g-mr-5  g-bg-blue-lineargradient-v4 col-md-4 col-xl-3 col-lg-3 col-sm-12" role="alert">
      <h3 class="h2 g-font-weight-300 g-mb-20 text-center">Novedades</h3>
      <p class="mb-0 text-white text-center">Enterate de novedades, descuentos y nuevos productos.</p>
      <br><br>
      <div class="text-center">
        <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase g-py-12 g-px-25" href="<?php echo base_url('index.php/Electrobras/Novedades');?>">Ver nodedades</a>
      </div>
    </div>

    <div class="u-shadow-v1-5 g-line-height-2 g-pa-30 g-mb-30 g-mr-5 g-bg-blue-lineargradient-v4 col-md-4 col-xl-3 col-lg-3 col-sm-12" role="alert">
      <h3 class="h2 g-font-weight-300 g-mb-20 text-center">Nuestro personal</h3>
      <p class="mb-0 text-white text-center">Personal capacitado e idóneo para asesorar a quien lo requiera, una excelente atención personalizada.</p>
    </div>
    <div class="u-shadow-v1-5 g-line-height-2 g-pa-30 g-mb-30 g-ml-5 g-bg-blue-lineargradient-v4 col-md-4 col-xl-3 col-lg-3 col-sm-12" role="alert">
      <h3 class="h2 g-font-weight-300 g-mb-20 text-center">Nuestros productos</h3>
      <p class="mb-0 text-white text-center">Todos nuestros productos son de primera calidad y al mejor precio, si quiere enterarse de las marcas que ofrecemos dirijase al siguiente link.</p>
      <div class="text-center">
        <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase g-py-12 g-px-25" href="<?php echo base_url('index.php/Electrobras/Electricidad');?>">Ver marcas</a>
      </div>
    </div>  
  </div>
<!-- End Box Shadow -->


 <div class="container g-pos-rel g-z-index-1 g-pb-80 hidden-xl-down">
    <div id="carouselCus2" class="js-carousel"
         data-infinite="true"
         data-autoplay="true"
         data-lazy-load="ondemand"
         data-slides-show="6">
          <div class="js-slide u-block-hover">
            <img class="mx-auto g-width-80 u-block-hover__main--grayscale g-opacity-0_3 g-opacity-1--hover g-cursor-pointer" 
            data-lazy="<?php echo base_url('assets/img/example/200x100/img1.png')?>">
          </div>
          <div class="js-slide u-block-hover">
            <img class="mx-auto g-width-80 u-block-hover__main--grayscale g-opacity-0_3 g-opacity-1--hover g-cursor-pointer" 
            data-lazy="<?php echo base_url('assets/img/example/200x100/img1.png')?>">
          </div>
          <div class="js-slide u-block-hover">
            <img class="mx-auto g-width-80 u-block-hover__main--grayscale g-opacity-0_3 g-opacity-1--hover g-cursor-pointer" 
            data-lazy="<?php echo base_url('assets/img/example/200x100/img1.png')?>">
          </div>
          <div class="js-slide u-block-hover">
            <img class="mx-auto g-width-80 u-block-hover__main--grayscale g-opacity-0_3 g-opacity-1--hover g-cursor-pointer" 
            data-lazy="<?php echo base_url('assets/img/example/200x100/img1.png')?>">
          </div>
          <div class="js-slide u-block-hover">
            <img class="mx-auto g-width-80 u-block-hover__main--grayscale g-opacity-0_3 g-opacity-1--hover g-cursor-pointer" 
            data-lazy="<?php echo base_url('assets/img/example/200x100/img1.png')?>">
          </div>
          <div class="js-slide u-block-hover">
            <img class="mx-auto g-width-80 u-block-hover__main--grayscale g-opacity-0_3 g-opacity-1--hover g-cursor-pointer" 
            data-lazy="<?php echo base_url('assets/img/example/200x100/img1.png')?>">
          </div>
    </div>
  </div>

</section>


      <!-- Icon Blocks v28 -->
      <section class="g-py-50">
        <div class="container">
          <div id="shortcode28">
            <div class="shortcode-html">
              <!-- Icon Blocks -->
              <div class="row">
                <div class="col-md-4 col-lg-4 g-mb-30">
                  <!-- Icon Blocks -->
                  <div class="text-center">
                    <span class="u-icon-v2 u-icon-size--3xl g-brd-7 g-brd-gray-light-v4 g-color-primary g-rounded-50x g-mb-25">
                      <i class="icon-education-008 u-line-icon-pro"></i>
                    </span>
                    <h3 class="h5 g-color-black mb-25">Novedades</h3>
                    <p class="g-color-gray-dark-v4 g-mb-0"> Enterate de novedades, descuentos y nuevos productos. </p>
                    <div class="text-center">
                      <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase p-3 mt-3" href="<?php echo base_url('index.php/Electrobras/Novedades');?>">Ver nodedades</a>
                    </div>
                  </div>
                  <!-- End Icon Blocks -->
                </div>

                <div class="col-md-4 col-lg-4 g-mb-30">
                  <!-- Icon Blocks -->
                  <div class="text-center">
                    <span class="u-icon-v2 u-icon-size--3xl g-brd-7 g-brd-gray-light-v4 g-color-primary g-rounded-50x g-mb-25">
                      <i class="icon-hotel-restaurant-170 u-line-icon-pro"></i>
                    </span>
                    <h3 class="h5 g-color-black mb-25">Nuestro pesonal</h3>
                    <p class="g-color-gray-dark-v4 g-mb-0">
                      Personal capacitado e idóneo para asesorar a quien lo requiera, una excelente atención personalizada.
                    </p>
                  </div>
                  <!-- End Icon Blocks -->
                </div>

                <div class="col-md-4 col-lg-4 g-mb-30">
                  <!-- Icon Blocks -->
                  <div class="text-center">
                    <span class="u-icon-v2 u-icon-size--3xl g-brd-7 g-brd-gray-light-v4 g-color-primary g-rounded-50x g-mb-25">
                      <i class="icon-electronics-154 u-line-icon-pro"></i>
                    </span>
                    <h3 class="h5 g-color-black mb-25">Nuestros productos</h3>
                    <p class="g-color-gray-dark-v4 g-mb-0">Todos nuestros productos son de primera calidad y al mejor precio, si quiere enterarse de las marcas que ofrecemos dirijase al siguiente link.</p>
                    <div class="text-center">
                      <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase g-py-12 g-px-25 mt-2" href="<?php echo base_url('index.php/Electrobras/Electricidad');?>">Ver marcas</a>
                    </div>
                  </div>
                  <!-- End Icon Blocks -->
                </div>
<!-- 
                <div class="col-md-6 col-lg-3 g-mb-30">

                  <div class="text-center">
                    <span class="u-icon-v2 u-icon-size--3xl g-brd-7 g-brd-gray-light-v4 g-color-primary g-rounded-50x g-mb-25">
                      <i class="icon-finance-256 u-line-icon-pro"></i>
                    </span>
                    <h3 class="h5 g-color-black mb-25">Clean code</h3>
                    <p class="g-color-gray-dark-v4 g-mb-0">We strive to embrace and drive change in our industry which allows us to keep our clients relevant.</p>
                  </div>

                </div> -->
              </div>
              <!-- End Icon Blocks -->
            </div>
          </div>
        </div>
      </section>
      <!-- End Icon Blocks v28 -->

    <!-- Our Services -->
    <section class="g-py-20">
      <div class="container">
        <header class="text-center g-width-60x--md mx-auto g-mb-80">
          <div class="u-heading-v2-3--bottom g-brd-primary g-mb-20">
            <h2 class="h3 u-heading-v2__title g-color-gray-dark-v2 text-uppercase g-font-weight-600">Electrobras SRL</h2>
          </div>
          <p class="lead">Somos una empresa líder de la Patagonia para la Patagonia dedicada a la venta de electricidad e iluminación para el hogar, comercio, e industria. Con una trayectoria de 25 años en el mercado.</p>
        </header>

        <div class="row">
          <div class="col-lg-4 g-mb-60 g-mb-0--lg">
            <!-- Icon Blocks -->
            <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
              <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
                  <i class="icon-education-008 u-line-icon-pro"></i>
                </span>
              <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Novedades</h3>
              <p class="g-mb-15">Enterate de novedades, descuentos y nuevos productos.</p>
              <div class="text-center">
                <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase p-3 mt-3" href="<?php echo base_url('index.php/Electrobras/Novedades');?>">Ver nodedades</a>
              </div>
            </div>
            <!-- End Icon Blocks -->
          </div>

          <div class="col-lg-4 g-mb-60 g-mb-0--lg">
            <!-- Icon Blocks -->
            <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
              <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
                  <i class="icon-finance-128 u-line-icon-pro"></i>
                </span>
              <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Nuestro personal</h3>
              <p class="g-mb-15">Personal capacitado e idóneo para asesorar a quien lo requiera, una excelente atención personalizada. </p>
            </div>
            <!-- End Icon Blocks -->
          </div>

          <div class="col-lg-4">
            <!-- Icon Blocks -->
            <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
              <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
                  <i class="icon-finance-218 u-line-icon-pro"></i>
                </span>
              <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Nuestros productos</h3>
              <p class="g-mb-15">Todos nuestros productos son de primera calidad y al mejor precio, si quiere enterarse de las marcas que ofrecemos dirijase al siguiente link.</p>
              <div class="text-center">
                <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase g-py-12 g-px-25 mt-2" href="<?php echo base_url('index.php/Electrobras/Electricidad');?>">Ver marcas</a>
              </div>
            </div>
            <!-- End Icon Blocks -->
          </div>
        </div>
      </div>
    </section>
    <!-- End Our Services -->




                  





 