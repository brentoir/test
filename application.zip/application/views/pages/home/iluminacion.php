<div class="container">
  <div class="row">
    <div class="u-shadow-v1-3 g-line-height-2 g-pa-40 g-mb-30" role="alert">
      <h3 class="h2 g-font-weight-300 g-mb-20">Ilunimación</h3>
      <p class="mb-0">A continuación proporcionamos un listado de empresas a las cuales puede consultar sus productos para luego realizar un pedido al siguiente link.</p>
    </div>
        <?php foreach ($iluminacion as $img): ?>
            <div class="col-md-3 col-sm-6 g-mb-30 ">
               <img class="img-fluid" src="<?php echo base_url('assets/img/productos/iluminacion/').$img;?>" alt="Image Description">
            </div>
        <?php endforeach ?>
  </div>
</div>
                  