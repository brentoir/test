<!-- Our Services -->
<section class="g-py-20">
  <div class="container">
    <header class="text-center g-width-60x--md mx-auto g-mb-80">
      <div class="u-heading-v2-3--bottom g-brd-primary g-mb-20">
        <h2 class="h3 u-heading-v2__title g-color-gray-dark-v2 text-uppercase g-font-weight-600">Electrobras SRL</h2>
      </div>
      <p class="lead">Somos una empresa líder de la Patagonia para la Patagonia dedicada a la venta de electricidad e iluminación para el hogar, comercio, e industria. Con una trayectoria de 25 años en el mercado.</p>
    </header>

    <div class="row">
      <div class="col-lg-4 g-mb-60 g-mb-0--lg">
        <!-- Icon Blocks -->
        <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
          <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
              <i class="icon-education-008 u-line-icon-pro "></i>
            </span>
          <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Novedades</h3>
          <p class="g-mb-15">Enterate de novedades, descuentos y nuevos productos.</p>
          <div class="text-center">
            <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase p-3 mt-3" href="<?php echo base_url('index.php/Electrobras/Novedades');?>">Ver nodedades</a>
          </div>
        </div>
        <!-- End Icon Blocks -->
      </div>

      <div class="col-lg-4 g-mb-60 g-mb-0--lg">
        <!-- Icon Blocks -->
        <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
          <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
              <i class="icon-hotel-restaurant-170 u-line-icon-pro"></i>
            </span>
          <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Nuestro personal</h3>
          <p class="g-mb-15">Personal capacitado e idóneo para asesorar a quien lo requiera, una excelente atención personalizada. </p>
        </div>
        <!-- End Icon Blocks -->
      </div>

      <div class="col-lg-4">
        <!-- Icon Blocks -->
        <div class="g-brd-around g-brd-gray-light-v4 text-center rounded g-px-30 g-pb-30">
          <span class="u-icon-v3 u-icon-size--lg g-color-white g-bg-primary g-pull-50x-up rounded-circle">
              <i class="icon-electronics-154 u-line-icon-pro"></i>
            </span>
          <h3 class="h4 g-color-gray-dark-v2 g-mb-10">Nuestros productos</h3>
          <p class="g-mb-15">Todos nuestros productos son de primera calidad y al mejor precio, si quiere enterarse de las marcas que ofrecemos dirijase al siguiente link.</p>
          <div class="text-center">
            <a class="btn u-btn-indigo u-btn-inset g-font-size-12 text-uppercase g-py-12 g-px-25 mt-2" href="<?php echo base_url('index.php/Electrobras/Electricidad');?>">Ver marcas</a>
          </div>
        </div>
        <!-- End Icon Blocks -->
      </div>
    </div>
  </div>
</section>
<!-- End Our Services -->

<section class="container-fluid g-py-50">

  <div class="row justify-content-center">
    <div class="col-md-6 col-sm-12 g-mb-30">
      <a class="js-fancybox" href="<?php echo base_url('assets/img/novedades/inicio/thumb/nov01b.jpg');?>" title="Single Image" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-blur-bg="true">
        <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/inicio/thumb/nov01b.jpg');?>" alt="Image Description">
      </a>
    </div>
    <div class="col-md-6 col-sm-12 g-mb-30">
      <a class="js-fancybox" href="<?php echo base_url('assets/img/novedades/inicio/thumb/nov02b.jpg');?>" title="Single Image" data-fancybox-animate-in="zoomIn" data-fancybox-animate-out="zoomOut" data-blur-bg="true">
        <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/inicio/thumb/nov02b.jpg');?>" alt="Image Description">
      </a>
    </div>
  </div>
</section>






                  





 