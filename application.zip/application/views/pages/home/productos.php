<!-- ################################################################################## -->
      <!-- Products -->
      <div class="container">
        <div class="row">
          <!-- Content -->
          <div class="col-md-9 flex-md-unordered">
            <div class="g-pl-15--lg">
              <!-- Filters -->
              <div class="d-flex justify-content-end align-items-center g-brd-bottom g-brd-gray-light-v4 g-pt-40 g-pb-20">




              </div>
              <!-- End Filters -->

              <!-- Products -->
              <div class="g-brd-bottom g-brd-gray-light-v4">
                <div class="row g-pt-30">
                  <div class="col-6 col-sm-5 col-lg-4 g-mb-30">
                    <div class="g-pos-rel">
                      <img class="img-fluid" src="<?php echo base_url('assets/img/productos/pro01.png');?>" alt="Image Description">
                    </div>
                  </div>

                  <div class="col-6 col-sm-7 col-lg-8 g-mb-15">
                    <!-- Product Info -->
                    <div class="g-mb-30">
                      <h4 class="h5 g-color-black mb-0 mt-1">
                        <a class="u-link-v5 g-color-black g-color-primary--hover" href="#">
                          PACKSHOT PROSYLVA 2TZ TOT 1L
                        </a>
                      </h4>
                      <a class="d-inline-block g-color-gray-dark-v5 g-font-size-13 mb-2" href="#">Agro</a>
                      <span class="d-block g-color-black g-font-size-20 mb-4">$52.00</span>
                      <p>Descripción del producto.</p>
                    </div>
                    <!-- End Product Info -->


                  </div>
                </div>
              </div>
              <!-- End Products -->

              <!-- Products -->
              <div class="g-brd-bottom g-brd-gray-light-v4">
                <div class="row g-pt-30">
                  <div class="col-6 col-sm-5 col-lg-4 g-mb-30">
                    <img class="img-fluid" src="<?php echo base_url('assets/img/productos/pro02.png');?>" alt="Image Description">
                  </div>

                  <div class="col-6 col-sm-7 col-lg-8 g-mb-15">
                    <!-- Product Info -->
                    <div class="g-mb-30">
                      <h4 class="h5 g-color-black mb-0 mt-1">
                        <a class="u-link-v5 g-color-black g-color-primary--hover" href="#">
                          PACKSHOT MTC 220  4L
                        </a>
                      </h4>
                      <a class="d-inline-block g-color-gray-dark-v5 g-font-size-13 mb-2" href="#">Agro</a>
                      <div class="mb-4">
                        <span class="g-color-black g-font-size-20 mr-2">$99.00</span>
                        
                      </div>
                      <p>Descripción del producto.</p>
                    </div>
                    <!-- End Product Info -->


                  </div>
                </div>
              </div>
              <!-- End Products -->

              <!-- Products -->
              <div class="g-brd-bottom g-brd-gray-light-v4">
                <div class="row g-pt-30">
                  <div class="col-6 col-sm-5 col-lg-4 g-mb-30">
                    <div class="g-pos-rel">
                      <img class="img-fluid" src="<?php echo base_url('assets/img/productos/pro03.png');?>" alt="Image Description">


                    </div>
                  </div>

                  <div class="col-6 col-sm-7 col-lg-8 g-mb-15">
                    <!-- Product Info -->
                    <div class="g-mb-30">
                      <h4 class="h5 g-color-black mb-0 mt-1">
                        <a class="u-link-v5 g-color-black g-color-primary--hover" href="#">
                          Classic Jacket
                        </a>
                      </h4>
                      <a class="d-inline-block g-color-gray-dark-v5 g-font-size-13 mb-2" href="#">Man</a>
                      <span class="d-block g-color-black g-font-size-20 mb-4">$49.99</span>
                      <p>Alongside our classic parka, we make modern clothing and outerwear that withstands the weather and the changes in fashion. We use only the best fabrics to keep you warm and dry, while the designs look good now and tomorrow. In essence, our coats are built to last.</p>
                    </div>
                    <!-- End Product Info -->


                  </div>
                </div>
              </div>
              <!-- End Products -->

              <!-- Products -->
              <div class="g-brd-bottom g-brd-gray-light-v4">
                <div class="row g-pt-30">
                  <div class="col-6 col-sm-5 col-lg-4 g-mb-30">
                    <img class="img-fluid" src="<?php echo base_url('assets/img/productos/pro04.png');?>" alt="Image Description">
                  </div>

                  <div class="col-6 col-sm-7 col-lg-8 g-mb-15">
                    <!-- Product Info -->
                    <div class="g-mb-30">
                      <h4 class="h5 g-color-black mb-0 mt-1">
                        <a class="u-link-v5 g-color-black g-color-primary--hover" href="#">
                          Wool lined parka
                        </a>
                      </h4>
                      <a class="d-inline-block g-color-gray-dark-v5 g-font-size-13 mb-2" href="#">Woman</a>
                      <div class="mb-4">
                        <span class="g-color-black g-font-size-20 mr-2">$75.00</span>
                        <s class="g-color-lightred g-font-weight-500 g-font-size-13">$82.37</s>
                      </div>
                      <p>Alongside our classic parka, we make modern clothing and outerwear that withstands the weather and the changes in fashion. We use only the best fabrics to keep you warm and dry, while the designs look good now and tomorrow. In essence, our coats are built to last.</p>
                    </div>
                    <!-- End Product Info -->

                  </div>
                </div>
              </div>
              <!-- End Products -->

            </div>
          </div>
          <!-- End Content -->

          <!-- Filters -->
          <div class="col-md-3 flex-md-first g-brd-right--lg g-brd-gray-light-v4 g-pt-40">
            <div class="g-pr-15--lg g-pt-60">
              <!-- Categories -->
              <div class="g-mb-30">
                <h3 class="h5 mb-3">Categorias</h3>

                <ul class="list-unstyled">
                  <li class="my-3">
                    <a class="d-block u-link-v5 g-color-gray-dark-v4 g-color-primary--hover" href="#">Agro
                      
                  </li>
                  <li class="my-3">
                    <a class="d-block u-link-v5 g-color-gray-dark-v4 g-color-primary--hover" href="#">Car care + aditivos
                      
                  </li>
                  <li class="my-3">
                    <a class="d-block u-link-v5 g-color-gray-dark-v4 g-color-primary--hover" href="#">Evolution
                      
                  </li>
                  <li class="my-3">
                    <a class="d-block u-link-v5 g-color-gray-dark-v4 g-color-primary--hover" href="#">Liquido de frenos
                      
                  </li>
                  <li class="my-3">
                    <a class="d-block u-link-v5 g-color-gray-dark-v4 g-color-primary--hover" href="#">Moto
                      
                  </li>
                  <li class="my-3">
                    <a class="d-block u-link-v5 g-color-gray-dark-v4 g-color-primary--hover" href="#">Neptuna
                      
                  </li>
                  <li class="my-3">
                    <a class="d-block u-link-v5 g-color-gray-dark-v4 g-color-primary--hover" href="#">Quartz
                      
                  </li>
                </ul>
              </div>
              <!-- End Categories -->

              <hr>

            </div>
          </div>
          <!-- End Filters -->
        </div>
      </div>
      <!-- End Products -->