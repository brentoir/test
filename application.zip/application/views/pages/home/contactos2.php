<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Google Maps | Unify - Responsive Website Template</title>

    <!-- Required Meta Tags Always Come First -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo base_url();?>favicon.ico">

    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap/offcanvas.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/icon-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/icon-hs/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/dzsparallaxer/dzsparallaxer.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/dzsparallaxer/dzsscroller/scroller.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/dzsparallaxer/advancedscroller/plugin.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/hs-megamenu/src/hs.megamenu.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/hamburgers/hamburgers.min.css">

    <!-- Show / Copy Code -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/malihu-scrollbar/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/prism/themes/prism.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/custombox/custombox.min.css">

    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/animate.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/jquery-ui/themes/base/jquery-ui.min.css">

    <!-- CSS Unify -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/unify.css">

    <!-- CSS Customization -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">
  </head>

  <body>
    <main>
      <!-- Header -->
      <header id="js-header" class="u-header u-header--static">
        <div class="u-header__section u-header__section--light g-bg-white g-transition-0_3 g-py-10">
          <nav class="js-mega-menu navbar navbar-toggleable-md">
            <!-- Responsive Toggle Button -->
            <button class="navbar-toggler navbar-toggler-right btn g-line-height-1 g-brd-none g-pa-0 g-pos-abs g-right-0" type="button"
                    aria-label="Toggle navigation"
                    aria-expanded="false"
                    aria-controls="navBar"
                    data-toggle="collapse"
                    data-target="#navBar">
              <span class="hamburger hamburger--slider">
                <span class="hamburger-box">
                  <span class="hamburger-inner"></span>
                </span>
              </span>
            </button>
            <!-- End Responsive Toggle Button -->

            <!-- Logo -->
            <a href="<?php echo base_url();?>index.html" class="navbar-brand">
              <img src="<?php echo base_url();?>assets/img/logo/logo-1.png" alt="Image Description">
            </a>
            <!-- End Logo -->

            <!-- Navigation -->
            <div class="collapse navbar-collapse align-items-center flex-sm-row g-pt-10 g-pt-5--lg g-ml-40--lg" id="navBar">
              <ul class="navbar-nav text-uppercase g-pos-rel g-font-weight-600 mr-auto">
                <!-- Intro -->
                <li class="nav-item g-mx-10--lg g-mx-15--xl">
                  <a href="<?php echo base_url();?>index.html" class="nav-link g-py-7 g-px-0">Intro</a>
                </li>
                <!-- End Intro -->

                <!-- Home -->
                <li class="hs-has-mega-menu nav-item g-mx-10--lg g-mx-15--xl"
                    data-animation-in="fadeIn"
                    data-animation-out="fadeOut"
                    data-max-width="60%"
                    data-position="left">
                  <a id="mega-menu-home" class="nav-link g-py-7 g-px-0" href="#" aria-haspopup="true" aria-expanded="false">Home
                    <i class="hs-icon hs-icon-arrow-bottom g-font-size-11 g-ml-7"></i></a>

                  <!-- Mega Menu -->
                  <div class="w-100 hs-mega-menu u-shadow-v11 font-weight-normal g-brd-top g-brd-primary g-brd-top-2 g-bg-white g-mt-17 g-mt-7--lg--scrolling" aria-labelledby="mega-menu-home">
                    <div class="row align-items-stretch no-gutters">
                      <!-- Home (col) -->
                      <div class="col-lg-6">
                        <ul class="list-unstyled">
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-default.html" class="nav-link">Home Default <span class="u-label g-rounded-3 g-font-size-10 g-bg-lightred g-py-3 g-pos-rel g-top-minus-1 g-ml-5">New</span></a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-1.html" class="nav-link">Home 1</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-2.html" class="nav-link">Home 2</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-3.html" class="nav-link">Home 3</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-4.html" class="nav-link">Home 4</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-5.html" class="nav-link">Home 5</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-6.html" class="nav-link">Home 6</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-7.html" class="nav-link">Home 7</a></li>
                        </ul>
                      </div>
                      <!-- End Home (col) -->

                      <!-- Home (col) -->
                      <div class="col-lg-6 g-brd-left--lg g-brd-gray-light-v5">
                        <ul class="list-unstyled">
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-8.html" class="nav-link">Home 8</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-9.html" class="nav-link">Home 9</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-10.html" class="nav-link">Home 10</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-11.html" class="nav-link">Home 11</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-12.html" class="nav-link">Home 12</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-13.html" class="nav-link">Home 13</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-14.html" class="nav-link">Home 14</a></li>
                          <li class="dropdown-item">
                            <a href="<?php echo base_url();?>unify-main/home/home-page-15.html" class="nav-link">Home 15</a></li>
                        </ul>
                      </div>
                      <!-- End Home (col) -->
                    </div>
                  </div>
                  <!-- End Mega Menu -->
                </li>
                <!-- End Home -->

                <!-- Pages -->
                <li class="nav-item hs-has-sub-menu g-mx-10--lg g-mx-15--xl"
                    data-animation-in="fadeIn"
                    data-animation-out="fadeOut">
                  <a id="nav-link-pages" class="nav-link g-py-7 g-px-0" href="#"
                     aria-haspopup="true"
                     aria-expanded="false"
                     aria-controls="nav-submenu-pages"
                  >Pages</a>

                  <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-20 g-mt-10--lg--scrolling" id="nav-submenu-pages"
                      aria-labelledby="nav-link-pages">
                    <!-- About -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--about" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--about"
                      >About</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--about"
                          aria-labelledby="nav-link--pages--about">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-about-1.html">About 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-about-2.html">About 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-about-3.html">About 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-about-4.html">About 4</a></li>
                        <li class="dropdown-divider"></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-about-me-1.html">About me 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-about-me-2.html">About me 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-about-me-3.html">About me 3</a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End About -->

                    <!-- Portfolios -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--portfolio" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--portfolio"
                      >Portfolios</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 u-dropdown-col-2 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--portfolio"
                          aria-labelledby="nav-link--pages--portfolio">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-case-study-1.html">Case Studies 1</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-case-study-2.html">Case Studies 2</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-1.html">Single item 1</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-2.html">Single item 2</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-3.html">Single item 3</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-4.html">Single item 4</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-5.html">Single item 5</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-6.html">Single item 6</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-7.html">Single item 7</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-8.html">Single item 8</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-portfolio-single-item-9.html">Single item 9</a>
                        </li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End Portfolios -->

                    <!-- Login &amp; Signup -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--login-signup" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--login-signup"
                      >Login &amp; Signup</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 u-dropdown-col-2 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--login-signup"
                          aria-labelledby="nav-link--pages--login-signup">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-and-signup-1.html">Login &amp; Signup</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-1.html">Signup 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-2.html">Signup 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-3.html">Signup 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-4.html">Signup 4</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-5.html">Signup 5</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-6.html">Signup 6</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-7.html">Signup 7</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-8.html">Signup 8</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-9.html">Signup 9</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-10.html">Signup 10</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-11.html">Signup 11</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-signup-12.html">Signup 12</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-1.html">login 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-2.html">Login 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-3.html">Login 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-4.html">Login 4</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-5.html">Login 5</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-6.html">Login 6</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-7.html">Login 7</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-8.html">Login 8</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-9.html">Login 9</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-10.html">Login 10</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-11.html">Login 11</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-login-12.html">Login 12</a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End Login &amp; Signup -->

                    <!-- Services -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--services" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--services"
                      >Services</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--services"
                          aria-labelledby="nav-link--pages--services">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-services-1.html">Services 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-services-2.html">Services 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-services-3.html">Services 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-services-4.html">Services 4</a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End Services -->

                    <!-- Search results -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--search-result" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--search-result"
                      >Search results</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--search-result"
                          aria-labelledby="nav-link--pages--search-result">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-search-results-grid-veiw-1.html">Grid View</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-search-results-grid-veiw-left-sidebar-1.html">Grid View
                            <span class="g-opacity-0_5">(with Sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-search-results-list-veiw-1.html">List View 1</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-search-results-list-veiw-2.html">List View 2</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-search-results-list-veiw-left-sidebar-1.html">List View
                            <span class="g-opacity-0_5">(with Sidebar)</span></a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End Search results -->

                    <!-- Profiles -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--profile" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--profile"
                      >Profiles</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 u-dropdown-col-2 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--profile"
                          aria-labelledby="nav-link--pages--profile">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-main-1.html">Main</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-profile-1.html">User</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-projects-1.html">Projects</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-comments-1.html">Comments</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-history-1.html">History</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-reviews-1.html">Reviews</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-settings-1.html">Settings</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-users-1.html">Contacts 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-users-1-full-width.html">Contacts 1
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-users-2.html">Contacts 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-profile-users-2-full-width.html">Contacts 2
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End Profiles -->

                    <!-- Сontacts -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--contacts" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--contacts"
                      >Сontacts</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 u-dropdown-col-2 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--contacts"
                          aria-labelledby="nav-link--pages--contacts">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-1.html">Сontacts 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-2.html">Сontacts 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-3.html">Сontacts 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-4.html">Сontacts 4</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-5.html">Сontacts 5</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-6.html">Сontacts 6</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-7.html">Сontacts 7</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-contacts-8.html">Сontacts 8</a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End Сontacts -->

                    <!-- Jobs -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--jobs" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--jobs"
                      >Jobs</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--jobs"
                          aria-labelledby="nav-link--pages--jobs">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-jobs-1.html">Jobs</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-jobs-description-right-sidebar-1.html">Jobs Description</a>
                        </li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End Jobs -->

                    <!-- Pricing -->
                    <li class="dropdown-item">
                      <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-pricing-1.html">Pricing</a></li>
                    <!-- End Pricing -->

                    <!-- FAQ -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--faq" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--faq"
                      >FAQ</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--faq"
                          aria-labelledby="nav-link--pages--faq">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-faq-1.html">FAQ 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-faq-2.html">FAQ 2</a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                    <!-- End FAQ -->

                    <!-- Others -->
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--others" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--others"
                      >Others</a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--others"
                          aria-labelledby="nav-link--pages--others">
                        <!-- Clients -->
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-clients-1.html">Clients</a></li>
                        <!-- End Clients -->

                        <!-- Terms -->
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-terms-1.html">Terms</a></li>
                        <!-- End Terms -->

                        <!-- Сookies -->
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-cookies-1.html">Сookies</a></li>
                        <!-- End Сookies -->

                        <!-- Invoice -->
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/pages/page-invoice-1.html">Invoice</a></li>
                        <!-- End Invoice -->

                        <!-- 404 -->
                        <li class="dropdown-item hs-has-sub-menu">
                          <a id="nav-link--pages--404" class="nav-link" href="#"
                             aria-haspopup="true"
                             aria-expanded="false"
                             aria-controls="nav-submenu--pages--404"
                          >404</a>

                          <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--404"
                              aria-labelledby="nav-link--pages--404">
                            <li class="dropdown-item">
                              <a class="nav-link" href="<?php echo base_url();?>specialty-pages/404/404-1.html">404 1</a></li>
                            <li class="dropdown-item">
                              <a class="nav-link" href="<?php echo base_url();?>specialty-pages/404/404-2.html">404 2</a></li>
                          </ul>
                        </li>
                        <!-- End 404 -->

                        <!-- Coming Soon -->
                        <li class="dropdown-item hs-has-sub-menu">
                          <a id="nav-link--pages--coming-soon" class="nav-link" href="#"
                             aria-haspopup="true"
                             aria-expanded="false"
                             aria-controls="nav-submenu--pages--coming-soon"
                          >Coming Soon</a>

                          <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--coming-soon"
                              aria-labelledby="nav-link--pages--coming-soon">
                            <li class="dropdown-item">
                              <a class="nav-link" href="<?php echo base_url();?>specialty-pages/coming-soon/page-coming-soon-1.html">Coming Soon</a>
                            </li>
                          </ul>
                        </li>
                        <!-- End Coming Soon -->
                      </ul>
                    </li>
                    <!-- End Others -->
                  </ul>
                </li>
                <!-- End Pages -->

                <!-- Blog -->
                <li class="nav-item hs-has-sub-menu g-mx-10--lg g-mx-15--xl"
                    data-animation-in="fadeIn"
                    data-animation-out="fadeOut">
                  <a id="nav-link--blog" class="nav-link g-py-7 g-px-0" href="#"
                     aria-haspopup="true"
                     aria-expanded="false"
                     aria-controls="nav-submenu--blog"
                  >Blog</a>

                  <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-20 g-mt-10--lg--scrolling" id="nav-submenu--blog"
                      aria-labelledby="nav-link--blog">
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--blog--minimal" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--blog--minimal"
                      >Minimal</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--blog--minimal"
                          aria-labelledby="nav-link--pages--blog--minimal">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-1.html">Minimal 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-1-left-sidebar.html">Minimal 1
                            <span class="g-opacity-0_5">(left sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-1-right-sidebar.html">Minimal 1
                            <span class="g-opacity-0_5">(right sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-2.html">Minimal 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-2-left-sidebar.html">Minimal 2
                            <span class="g-opacity-0_5">(left sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-2-right-sidebar.html">Minimal 2
                            <span class="g-opacity-0_5">(right sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-3.html">Minimal 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-3-left-sidebar.html">Minimal 3
                            <span class="g-opacity-0_5">(left sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-3-right-sidebar.html">Minimal 3
                            <span class="g-opacity-0_5">(right sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-4.html">Minimal 4</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-4-left-sidebar.html">Minimal 4
                            <span class="g-opacity-0_5">(left sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-minimal-4-right-sidebar.html">Minimal 4
                            <span class="g-opacity-0_5">(right sidebar)</span></a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>

                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--blog--grid-bg" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--blog--grid-bg"
                      >Grid Background</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--blog--grid-bg"
                          aria-labelledby="nav-link--pages--blog--grid-bg">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-background-overlay-2.html">Column 2</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-background-overlay-left-sidebar.html">Column 2
                            <span class="g-opacity-0_5">(left sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-background-overlay-right-sidebar.html">Column 2
                            <span class="g-opacity-0_5">(right sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-background-overlay-3.html">Column 3</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-background-overlay-3-fullwidth.html">Column 3
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-background-overlay-4.html">Column 4</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-background-overlay-4-fullwidth.html">Column 4
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>

                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--blog--grid-classic" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--blog--grid-classic"
                      >Grid Classic</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--blog--grid-classic"
                          aria-labelledby="nav-link--pages--blog--grid-classic">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-classic-2.html">Column 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-classic-left-sidebar.html">Column 2
                            <span class="g-opacity-0_5">(left sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-classic-right-sidebar.html">Column 2
                            <span class="g-opacity-0_5">(right sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-classic-3.html">Column 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-classic-3-fullwidth.html">Column 3
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-classic-4.html">Column 4</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-classic-4-fullwidth.html">Column 4
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>

                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--blog--grid-modern" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--blog--grid-modern"
                      >Grid Modern</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--blog--grid-modern"
                          aria-labelledby="nav-link--pages--blog--grid-modern">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-modern-1.html">Modern 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-modern-2.html">Modern 2</a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>

                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--blog--grid-overlap" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--blog--grid-overlap"
                      >Grid Overlap</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--blog--grid-overlap"
                          aria-labelledby="nav-link--pages--blog--grid-overlap">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-overlap-2.html">Column 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-overlap-left-sidebar.html">Column 2
                            <span class="g-opacity-0_5">(left sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-overlap-right-sidebar.html">Column 2
                            <span class="g-opacity-0_5">(right sidebar)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-overlap-3.html">Column 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-overlap-3-fullwidth.html">Column 3
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-grid-overlap-4-fullwidth.html">Column 4
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>

                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--blog--masonry" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--blog--masonry"
                      >Masonry</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--blog--masonry"
                          aria-labelledby="nav-link--pages--blog--masonry">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-masonry-col-2.html">Column 2</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-masonry-col-3.html">Column 3</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-masonry-col-3-fullwidth.html">Column 3
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-masonry-col-4.html">Column 4</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-masonry-col-4-fullwidth.html">Column 4
                            <span class="g-opacity-0_5">(full width)</span></a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>

                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--pages--blog--single-item" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--pages--blog--single-item"
                      >Single items</a>

                      <!-- Submenu (level 2) -->
                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--pages--blog--single-item"
                          aria-labelledby="nav-link--pages--blog--single-item">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-single-item-1.html">Single item 1</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/blog/blog-single-item-2.html">Single item 2</a></li>
                      </ul>
                      <!-- End Submenu (level 2) -->
                    </li>
                  </ul>
                </li>
                <!-- End Blog -->

                <!-- Features -->
                <li class="nav-item hs-has-sub-menu g-mx-10--lg g-mx-15--xl"
                    data-animation-in="fadeIn"
                    data-animation-out="fadeOut">
                  <a id="nav-link--features" class="nav-link g-py-7 g-px-0" href="#"
                     aria-haspopup="true"
                     aria-expanded="false"
                     aria-controls="nav-submenu--features"
                  >Features</a>

                  <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-20 g-mt-10--lg--scrolling" id="nav-submenu--features"
                      aria-labelledby="nav-link--features">
                    <li class="dropdown-item">
                      <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/headers/index.html">Headers</a></li>
                    <li class="dropdown-item">
                      <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/promo/shortcode-blocks-promo.html">Promo blocks</a>
                    </li>
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--features--sliders" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--features--sliders"
                      >Sliders <span class="u-label g-rounded-3 g-font-size-10 g-bg-lightred g-py-3 g-pos-rel g-top-minus-1 g-ml-5">New</span></a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--features--sliders"
                          aria-labelledby="nav-link--features--sliders">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>revolution-slider/index.html">Revolution sliders</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>master-slider/index.html">Master sliders</a></li>
                      </ul>
                    </li>
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--features--pop-ups" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--features--pop-ups"
                      >Pop-ups</a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--features--pop-ups"
                          aria-labelledby="nav-link--features--pop-ups">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-lightbox.html">Lightbox</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-modals.html">Modals</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-gallery.html">Gallery</a>
                        </li>
                      </ul>
                    </li>
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--features--maps" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--features--maps"
                      >Maps</a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--features--maps"
                          aria-labelledby="nav-link--features--maps">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-google-maps.html">Google Maps</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-maps-with-pins.html">Maps With Pins</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-vector-maps.html">Vector Maps</a>
                        </li>
                      </ul>
                    </li>
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--features--footers" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--features--footers"
                      >Footers</a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--features--footers"
                          aria-labelledby="nav-link--features--footers">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-classic.html">Classic Footers</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-contact-forms.html">Contact Forms</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-maps.html">Footers Maps</a>
                        </li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-modern.html">Modern Footers</a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <!-- End Features -->

                <!-- Shortcodes -->
                <li class="nav-item g-mx-10--lg g-mx-15--xl">
                  <a href="<?php echo base_url();?>unify-main/shortcodes/index.html" class="nav-link g-py-7 g-px-0">Shortcodes</a>
                </li>
                <!-- End Shortcodes -->

                <!-- Demos -->
                <li class="nav-item hs-has-sub-menu g-mx-10--lg g-mx-15--xl"
                    data-animation-in="fadeIn"
                    data-animation-out="fadeOut">
                  <a id="nav-link-demos" class="nav-link g-py-7 g-px-0" href="#"
                     aria-haspopup="true"
                     aria-expanded="false"
                     aria-controls="nav-submenu-demos"
                  >Demos</a>

                  <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-20 g-mt-10--lg--scrolling" id="nav-submenu-demos"
                      aria-labelledby="nav-link-demos">
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--demos--one-page" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--demos--one-page"
                      >One Pages</a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 u-dropdown-col-2 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--demos--one-page"
                          aria-labelledby="nav-link--demos--one-page">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/accounting/index.html">Accounting</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/agency/index.html">Agency</a>
                        </li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/app/index.html">App</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/architecture/index.html">Architecture</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/business/index.html">Business</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/charity/index.html">Charity</a>
                        </li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/consulting/index.html">Сonsulting <span class="u-label g-rounded-3 g-font-size-10 g-bg-lightred g-py-3 g-pos-rel g-top-minus-1 g-ml-5">New</span></a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/construction/index.html">Construction</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/courses/index.html">Courses</a>
                        </li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/corporate/index.html">Corporate <span class="u-label g-rounded-3 g-font-size-10 g-bg-lightred g-py-3 g-pos-rel g-top-minus-1 g-ml-5">New</span></a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/event/index.html">Event</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/gym/index.html">GYM</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/lawyer/index.html">Lawyer</a>
                        </li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/music/index.html">Music</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/photography/index.html">Photography</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/real-estate/index.html">Real Estate</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/restaurant/index.html">Restaurant</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>one-pages/shipping/index.html">Shipping</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/spa/index.html">Spa</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/travel/index.html">Travel</a>
                        </li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>one-pages/wedding/index.html">Wedding</a>
                        </li>
                      </ul>
                    </li>
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--demos--e-commerce" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--demos--e-commerce"
                      >E-Commerce</a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--demos--e-commerce"
                          aria-labelledby="nav-link--demos--e-commerce">
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>e-commerce/index.html">Main Page</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>e-commerce/page-grid-filter-1.html">Grid Filter</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>e-commerce/page-list-filter-1.html">List Filter</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>e-commerce/page-product-1.html">Product</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>e-commerce/page-checkout-1.html">Сheckout</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>e-commerce/page-login-1.html">Login</a>
                        </li>
                        <li class="dropdown-item"><a class="nav-link" href="<?php echo base_url();?>e-commerce/page-signup-1.html">Signup</a>
                        </li>
                      </ul>
                    </li>
                    <li class="dropdown-item hs-has-sub-menu">
                      <a id="nav-link--demos--blog-magazine" class="nav-link" href="#"
                         aria-haspopup="true"
                         aria-expanded="false"
                         aria-controls="nav-submenu--demos--blog-magazine"
                      >Blogs &amp; Magazines</a>

                      <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2" id="nav-submenu--demos--blog-magazine"
                          aria-labelledby="nav-link--demos--blog-magazine">
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>blog-magazine/classic/bm-classic-home-1.html">Home</a></li>
                        <li class="dropdown-item">
                          <a class="nav-link" href="<?php echo base_url();?>blog-magazine/classic/bm-classic-single-1.html">Single</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <!-- End Demos -->
              </ul>
            </div>
            <!-- End Navigation -->

            <div class="d-inline-block hidden-xs-down g-pos-rel g-valign-middle g-pl-30 g-pl-0--lg">
              <a class="btn u-btn-outline-primary g-font-size-13 text-uppercase g-py-10 g-px-15" href="https://wrapbootstrap.com/theme/unify-responsive-website-template-WB0412697" target="_blank">Purchase now</a>
            </div>
          </nav>
        </div>
      </header>
      <!-- End Header -->

      <section class="container-fluid">
        <div class="row row-offcanvas row-offcanvas-left">
          <div class="col-sm-4 col-lg-3 col-xl-2 sidebar-offcanvas u-sidebar-navigation g-bg-secondary g-pa-20">

            <div class="form-group g-mb-20">
              <input id="autocomplete1" class="form-control form-control-md" type="text" placeholder="Search"
                     data-url="<?php echo base_url();?>assets/include/ajax/autocomplete-data-shortcode-search.json">
            </div>

            <ul class="js-shortcode-filter list-inline u-hs-filter g-pt-20 g-my-10">
              <li class="list-inline-item active g-mr-10 g-mb-10"><a href="#" data-shortcode-filter="all">All</a></li>
              <li class="list-inline-item g-mr-10 g-mb-10"><a href="#" data-shortcode-filter="bases">Bases</a></li>
              <li class="list-inline-item"><a href="#" data-shortcode-filter="blocks">Blocks</a></li>
            </ul>

            <ul class="js-shortcode-filter-result nav flex-column">
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-accrodions.html" class="nav-link g-px-0">Accordions</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-alerts.html" class="nav-link g-px-0">Alerts</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-badges.html" class="nav-link g-px-0">Badges</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-blockquotes.html" class="nav-link g-px-0">Blockquotes</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-box-shadow.html" class="nav-link g-px-0">Box Shadow</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-breadcrumbs.html" class="nav-link g-px-0">Breadcrumbs</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-buttons.html" class="nav-link g-px-0">Buttons</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-dividers.html" class="nav-link g-px-0">Dividers</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-dynamic-process-blocks-1.html" class="nav-link g-px-0">Dynamic Process Blocks</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-lightbox.html" class="nav-link g-px-0">Lightbox</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-modals.html" class="nav-link g-px-0">Modals</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-gallery-grid.html" class="nav-link g-px-0">Gallery Grid</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-gradient-backgrounds.html" class="nav-link g-px-0">Gradient Backgrounds</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-labels.html" class="nav-link g-px-0">Labels</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-lists-group.html" class="nav-link g-px-0">Lists Group</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-media-audios.html" class="nav-link g-px-0">Media Audios</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-media-images.html" class="nav-link g-px-0">Media Images</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-media-videos.html" class="nav-link g-px-0">Media Videos</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-onscroll-animations.html" class="nav-link g-px-0">Onscroll Animations</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-paginations.html" class="nav-link g-px-0">Paginations</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-panels.html" class="nav-link g-px-0">Panels</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-progress-bars.html" class="nav-link g-px-0">Progress Bars</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-static-process-blocks-1.html" class="nav-link g-px-0">Static Process Blocks</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-tables.html" class="nav-link g-px-0">Tables</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-taglines.html" class="nav-link g-px-0">Taglines</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-tags.html" class="nav-link g-px-0">Tags</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-headings.html" class="nav-link g-px-0">Headings</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-typography.html" class="nav-link g-px-0">Typography</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-dropcaps.html" class="nav-link g-px-0">Dropcaps</a></li>
              <li class="js-shortcode-filter__item nav-item bases active"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-google-maps.html" class="nav-link g-px-0">Google Maps</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-vector-maps.html" class="nav-link g-px-0">Vector Maps</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-base-maps-with-pins.html" class="nav-link g-px-0">Maps With Pins</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/forms/shortcode-base-forms-bootstrap.html" class="nav-link g-px-0">Forms Bootstrap</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/forms/shortcode-base-forms-unify.html" class="nav-link g-px-0">Forms Unify</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/forms/shortcode-base-forms-horizontal-unify.html" class="nav-link g-px-0">Forms Horizontal Unify</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/forms/shortcode-base-forms-disabled-states-unify.html" class="nav-link g-px-0">Forms Disabled States Unify</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/forms/shortcode-base-forms-success-states-unify.html" class="nav-link g-px-0">Forms Success States unify</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/forms/shortcode-base-forms-error-states-unify.html" class="nav-link g-px-0">Forms Error States Unify</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icons.html" class="nav-link g-px-0">Icons</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icon-hovers.html" class="nav-link g-px-0">Icon Hovers</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icon-sizes.html" class="nav-link g-px-0">Icon Sizes</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-social-icons.html" class="nav-link g-px-0">Social Icons</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icon-fontawesome.html" class="nav-link g-px-0">Icon Fontawesome</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icon-line-icons-pro-1.html" class="nav-link g-px-0">Icon Line Icons Pro 1</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icon-line-icons-pro-2.html" class="nav-link g-px-0">Icon Line Icons Pro 2</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icon-simple-line-icons.html" class="nav-link g-px-0">Icon Simple Line Icons</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/icons/shortcode-base-icon-et-line-icon.html" class="nav-link g-px-0">Icon Et Line Icon</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/tabs/index.html" class="nav-link g-px-0">Tabs</a></li>
              <li class="js-shortcode-filter__item nav-item bases"><a href="<?php echo base_url();?>unify-main/shortcodes/portfolios/index.html" class="nav-link g-px-0">Portfolios</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/headers/index.html" class="nav-link g-px-0">Headers</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/promo/shortcode-blocks-promo.html" class="nav-link g-px-0">Promo</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-classic.html" class="nav-link g-px-0">Footer Classic</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-contact-forms.html" class="nav-link g-px-0">Footer Contact Forms</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-maps.html" class="nav-link g-px-0">Footer Maps</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/footers/shortcode-blocks-footer-modern.html" class="nav-link g-px-0">Footer Modern</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-banners.html" class="nav-link g-px-0">Banners</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-clients.html" class="nav-link g-px-0">Clients</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-comments.html" class="nav-link g-px-0">Comments</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-countdowns.html" class="nav-link g-px-0">Countdowns</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-counters.html" class="nav-link g-px-0">Counters</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-cta-boxed.html" class="nav-link g-px-0">Call To Action (boxed)</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-cta-full-width.html" class="nav-link g-px-0">Call To Action (full width)</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-gallery.html" class="nav-link g-px-0">Gallery</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-hero-info.html" class="nav-link g-px-0">Hero Info</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-hero-blocks.html" class="nav-link g-px-0">Hero Blocks</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-hero-content.html" class="nav-link g-px-0">Hero Content</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-icons.html" class="nav-link g-px-0">Icon Blocks</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-icons-app.html" class="nav-link g-px-0">Icons App</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-icons-interactive.html" class="nav-link g-px-0">Icons Interactive</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-info-blocks.html" class="nav-link g-px-0">Info Blocks</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-news.html" class="nav-link g-px-0">News</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-news-image.html" class="nav-link g-px-0">News Image</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-news-no-images.html" class="nav-link g-px-0">News No Images</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-news-small.html" class="nav-link g-px-0">News Small</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-tables.html" class="nav-link g-px-0">Table Designs</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-pricing-plans.html" class="nav-link g-px-0">Pricing Plans</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-pricing-sections.html" class="nav-link g-px-0">Pricing Sections</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-pricing-table.html" class="nav-link g-px-0">Pricing Table</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-products.html" class="nav-link g-px-0">Products</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-products-advanced.html" class="nav-link g-px-0">Products Advanced</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-products-list.html" class="nav-link g-px-0">Products List</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-products-overlay.html" class="nav-link g-px-0">Products Overlay</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-team.html" class="nav-link g-px-0">Team</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-team-advanced.html" class="nav-link g-px-0">Team Advanced</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-testimonials.html" class="nav-link g-px-0">Testimonials</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-testimonials-advanced.html" class="nav-link g-px-0">Testimonials Advanced</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-timelines.html" class="nav-link g-px-0">Timelines</a></li>
              <li class="js-shortcode-filter__item nav-item blocks"><a href="<?php echo base_url();?>unify-main/shortcodes/shortcode-blocks-users.html" class="nav-link g-px-0">Users</a></li>
            </ul>
          </div>
          <div class="col-sm-8 col-lg-9 col-xl-10 g-py-30 g-pa-30--md">
            <div class="hidden-md-up">
              <button type="button" class="btn btn-primary btn-sm" data-toggle="offcanvas">Toggle shocrtcode nav</button>
            </div>
      <div class="g-pt-30">
        <h1 class="g-font-weight-300 g-letter-spacing-1 g-mb-35">Google Maps</h1>
        <div class="container">
          <!-- Google Map Roadmap -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Roadmap</h3>
            </div>

            <div class="col-md-9">
              <div id="shortcode1">
                <div class="shortcode-html">
<div id="GMapRoadmap" class="js-g-map embed-responsive embed-responsive-21by9"
     data-lat="40.748866"
     data-lng="-73.988366"
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode1"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode1"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Roadmap -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Satellite -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Satellite</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode2">
                <div class="shortcode-html">
<div id="GMapSatellite" class="js-g-map embed-responsive embed-responsive-21by9"
     data-type="satellite"
     data-lat="40.748866"
     data-lng="-73.988366"
     data-title="HTMLSTREAM"
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode2"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode2"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Satellite -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Terrain -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Terrain</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode3">
                <div class="shortcode-html">
<div id="GMapTerrain" class="js-g-map embed-responsive embed-responsive-21by9"
     data-type="terrain"
     data-lat="40.748866"
     data-lng="-73.988366"
     data-title="HTMLSTREAM"
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode3"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode3"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Terrain -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Street View -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Street View</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode4">
                <div class="shortcode-html">
<div id="GMapStreetView" class="js-g-map embed-responsive embed-responsive-21by9"
     data-type="street-view"
     data-lat="40.748866"
     data-lng="-73.988366"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode4"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode4"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Street View -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Customized GMap: Light -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Customized GMap: Light</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode5">
                <div class="shortcode-html">
<div id="GMapCustomized-light" class="js-g-map embed-responsive embed-responsive-21by9"
     data-type="custom"
     data-lat="40.674"
     data-lng="-73.946"
     data-zoom="12"
     data-title="Agency"
     data-styles='[
       ["", "", [{"saturation":-100},{"lightness":51},{"visibility":"simplified"}]],
       ["", "labels", [{"visibility":"on"}]],
       ["water", "", [{"color":"#bac6cb"}]]
     ]'
     data-pin="true"
     data-pin-icon="<?php echo base_url();?>assets/img/icons/pin/green.png"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode5"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode5"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Customized GMap: Light -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Customized GMap: Dark -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Customized GMap: Dark</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode6">
                <div class="shortcode-html">
<div id="GMapCustomized-dark" class="js-g-map embed-responsive embed-responsive-21by9"
     data-type="custom"
     data-lat="40.674"
     data-lng="-73.946"
     data-zoom="12"
     data-title="Event"
     data-styles='[
       ["", "", [{"saturation":-100},{"lightness":50},{"visibility":"simplified"}]],
       ["", "geometry", [{"color":"#1e303d"}]],
       ["road", "", [{"color":"#ffffff"},{"lightness":-100}]],
       ["road", "labels.text.fill", [{"color":"#ffffff"},{"lightness":-50}]],
       ["water", "", [{"color":"#0e171d"}]]
     ]'
     data-pin="true"
     data-pin-icon="<?php echo base_url();?>assets/img/icons/pin/red.png"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode6"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode6"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Customized GMap: Dark -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Geolocation -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Geolocation</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode7">
                <div class="shortcode-html">
<div id="GMapGeolocation" class="js-g-map embed-responsive embed-responsive-21by9"
     data-lat="40.748866"
     data-lng="-73.988366"
     data-zoom="16"
     data-geolocation="true"
     data-title="HTMLSTREAM"
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode7"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode7"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Geolocation -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Polygon -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Polygon</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode8">
                <div class="shortcode-html">
<div id="GMapPolygon" class="js-g-map embed-responsive embed-responsive-21by9"
     data-lat="-12.043333"
     data-lng="-77.028333"
     data-zoom="14"
     data-polygon="true"
     data-polygon-cords='[
       [-12.040397656836609,-77.03373871559225],
       [-12.040248585302038,-77.03993927003302],
       [-12.050047116528843,-77.02448169303511],
       [-12.044804866577001,-77.02154422636042]
     ]'
     data-polygon-styles='{"strokeColor":"#BBD8E9","strokeOpacity":1,"strokeWeight":3,"fillColor":"#BBD8E9","fillOpacity":0.6}'
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode8"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode8"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Polygon -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Polylines -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Polylines</h3>
            </div>
            <div class="col-md-9">
              <div id="shortcode9">
                <div class="shortcode-html">
<div id="GMapPolylines" class="js-g-map embed-responsive embed-responsive-21by9"
     data-lat="-12.043333"
     data-lng="-77.028333"
     data-zoom="14"
     data-polylines="true"
     data-polylines-cords='[
       [-12.044012922866312, -77.02470665341184],
       [-12.05449279282314, -77.03024273281858],
       [-12.055122327623378, -77.03039293652341],
       [-12.075917129727586, -77.02764635449216],
       [-12.07635776902266, -77.02792530422971],
       [-12.076819390363665, -77.02893381481931],
       [-12.088527520066453, -77.0241058385925],
       [-12.090814532191756, -77.02271108990476]
     ]'
     data-polylines-styles='{"strokeColor":"#131540","strokeOpacity":0.6,"strokeWeight":6}'
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode9"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode9"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Polylines -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Routes -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Routes</h3>
            </div>

            <div class="col-md-9">
              <div id="shortcode10">
                <div class="shortcode-html">
<div id="GMapRoutes" class="js-g-map embed-responsive embed-responsive-21by9"
     data-lat="-12.043333"
     data-lng="-77.028333"
     data-zoom="14"
     data-routes="true"
     data-routes-cords='[
       [-12.044012922866312, -77.02470665341184],
       [-12.090814532191756, -77.02271108990476]
     ]'
     data-routes-styles='{"travelMode":"driving","strokeColor":"#131540","strokeOpacity":0.6,"strokeWeight":6}'
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode10"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode10"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Routes -->

          <hr class="g-brd-gray-light-v4 g-my-60">

          <!-- Google Map Geocoding -->
          <div class="row">
            <div class="col-md-3">
              <h3 class="h4 g-font-weight-300 g-mb-30">Google Map Geocoding</h3>
            </div>

            <div class="col-md-9">
              <div id="shortcode11">
                <div class="shortcode-html">
<form id="GMapGeocodingForm" class="g-mb-30">
  <div class="input-group g-brd-primary--focus g-mb-30">
    <input id="GMapGeocodingAddress" class="form-control rounded-0 u-form-control" type="text" placeholder="Enter address">

    <div class="input-group-addon p-0 g-brd-primary">
      <button class="btn rounded-0 btn-primary btn-md g-font-weight-700 g-font-size-14" type="submit">Submit</button>
    </div>
  </div>
</form>

<div id="GMapGeocoding" class="js-g-map embed-responsive embed-responsive-21by9"
     data-lat="-12.043333"
     data-lng="-77.028333"
     data-zoom="14"
     data-geocoding="true"
     data-cords-target="#GMapGeocodingAddress"
     data-pin="true"></div>
                </div>

                <div class="shortcode-scripts">
<!-- JS Implementing Plugins -->
<script type="text/plain" src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

<!-- JS Unify -->
<script type="text/plain" src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

<!-- JS Plugins Init. -->
<script type="text/plain">
  // initialization of google map
  function initMap() {
    $.HSCore.components.HSGMap.init('.js-g-map');
  }
</script>

<script type="text/plain" src="//maps.googleapis.com/maps/api/js?key=API_KEY&callback=initMap" async defer></script>
                </div>
              </div>

              <!-- Show Code -->
              <div class="g-font-size-12 g-my-50">
                <a class="js-modal-markup u-link-v5 g-color-main g-color-primary--hover g-mr-15" href="#"
                   data-content-target="#shortcode11"
                   data-modal-target="#modalMarkup"
                   data-modal-effect="fadein">
                  <i class="fa fa-code"></i> Show code
                </a>
                <a class="js-copy u-link-v5 g-color-main g-color-primary--hover" href="#"
                   data-content-target="#shortcode11"
                   data-success-text="Copied">
                  <i class="fa fa-clone"></i> Copy code
                </a>
              </div>
              <!-- End Show Code -->
            </div>
          </div>
          <!-- End Google Map Geocoding -->
        </div>
      </div>
          </div>
        </div>
      </section>

      <!-- Call To Action -->
      <section class="g-bg-primary g-color-white g-pa-30" style="background-image: url(<?php echo base_url();?>assets/img/bg/pattern5.png);">
        <div class="d-md-flex justify-content-md-center text-center">
          <div class="align-self-md-center">
            <p class="lead g-font-weight-400 g-mr-20--md g-mb-15 g-mb-0--md">We offer best in class service for your needs</p>
          </div>
          <div class="align-self-md-center">
            <a class="btn btn-lg u-btn-white text-uppercase g-font-weight-600 g-font-size-12" target="_blank" href="https://wrapbootstrap.com/theme/unify-responsive-website-template-WB0412697">Purchase Now</a>
          </div>
        </div>
      </section>
      <!-- End Call To Action -->

      <!-- Footer -->
      <div class="g-bg-black-opacity-0_9 g-color-white-opacity-0_8 g-py-60">
        <div class="container-fluid">
          <div class="row">
            <!-- Footer Content -->
            <div class="col-lg-3 col-md-6 g-mb-40 g-mb-0--lg">
              <div class="u-heading-v2-3--bottom g-brd-white-opacity-0_8 g-mb-20">
                <h2 class="u-heading-v2__title h6 text-uppercase mb-0">About Us</h2>
              </div>

              <p>About Unify dolor sit amet, consectetur adipiscing elit. Maecenas eget nisl id libero tincidunt sodales.</p>
            </div>
            <!-- End Footer Content -->

            <!-- Footer Content -->
            <div class="col-lg-3 col-md-6 g-mb-40 g-mb-0--lg">
              <div class="u-heading-v2-3--bottom g-brd-white-opacity-0_8 g-mb-20">
                <h2 class="u-heading-v2__title h6 text-uppercase mb-0">Latest Posts</h2>
              </div>

              <article>
                <h3 class="h6 g-mb-2">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Incredible template</a>
                </h3>
                <div class="small g-color-white-opacity-0_6">May 8, 2017</div>
              </article>

              <hr class="g-brd-white-opacity-0_1 g-my-10">

              <article>
                <h3 class="h6 g-mb-2">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">New features</a>
                </h3>
                <div class="small g-color-white-opacity-0_6">June 23, 2017</div>
              </article>

              <hr class="g-brd-white-opacity-0_1 g-my-10">

              <article>
                <h3 class="h6 g-mb-2">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">New terms and conditions</a>
                </h3>
                <div class="small g-color-white-opacity-0_6">September 15, 2017</div>
              </article>
            </div>
            <!-- End Footer Content -->

            <!-- Footer Content -->
            <div class="col-lg-3 col-md-6 g-mb-40 g-mb-0--lg">
              <div class="u-heading-v2-3--bottom g-brd-white-opacity-0_8 g-mb-20">
                <h2 class="u-heading-v2__title h6 text-uppercase mb-0">Useful Links</h2>
              </div>

              <nav class="text-uppercase1">
                <ul class="list-unstyled g-mt-minus-10 mb-0">
                  <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                    <h4 class="h6 g-pr-20 mb-0">
                      <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">About Us</a>
                      <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                    </h4>
                  </li>
                  <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                    <h4 class="h6 g-pr-20 mb-0">
                      <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Portfolio</a>
                      <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                    </h4>
                  </li>
                  <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                    <h4 class="h6 g-pr-20 mb-0">
                      <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Our Services</a>
                      <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                    </h4>
                  </li>
                  <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                    <h4 class="h6 g-pr-20 mb-0">
                      <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Latest Jobs</a>
                      <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                    </h4>
                  </li>
                  <li class="g-pos-rel g-py-10">
                    <h4 class="h6 g-pr-20 mb-0">
                      <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Contact Us</a>
                      <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                    </h4>
                  </li>
                </ul>
              </nav>
            </div>
            <!-- End Footer Content -->

            <!-- Footer Content -->
            <div class="col-lg-3 col-md-6">
              <div class="u-heading-v2-3--bottom g-brd-white-opacity-0_8 g-mb-20">
                <h2 class="u-heading-v2__title h6 text-uppercase mb-0">Our Contacts</h2>
              </div>

              <address class="g-bg-no-repeat g-font-size-12 mb-0" style="background-image: url(<?php echo base_url();?>assets/img/maps/map2.png);">
                <!-- Location -->
                <div class="d-flex g-mb-20">
                  <div class="g-mr-10">
                    <span class="u-icon-v3 u-icon-size--xs g-bg-white-opacity-0_1 g-color-white-opacity-0_6">
                      <i class="fa fa-map-marker"></i>
                    </span>
                  </div>
                  <p class="mb-0">795 Folsom Ave, Suite 600, <br> San Francisco, CA 94107 795</p>
                </div>
                <!-- End Location -->

                <!-- Phone -->
                <div class="d-flex g-mb-20">
                  <div class="g-mr-10">
                    <span class="u-icon-v3 u-icon-size--xs g-bg-white-opacity-0_1 g-color-white-opacity-0_6">
                      <i class="fa fa-phone"></i>
                    </span>
                  </div>
                  <p class="mb-0">(+123) 456 7890 <br> (+123) 456 7891</p>
                </div>
                <!-- End Phone -->

                <!-- Email and Website -->
                <div class="d-flex g-mb-20">
                  <div class="g-mr-10">
                    <span class="u-icon-v3 u-icon-size--xs g-bg-white-opacity-0_1 g-color-white-opacity-0_6">
                      <i class="fa fa-globe"></i>
                    </span>
                  </div>
                  <p class="mb-0">
                    <a class="g-color-white-opacity-0_8 g-color-white--hover" href="mailto:info@htmlstream.com">info@htmlstream.com</a>
                    <br>
                    <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">www.htmlstream.com</a>
                  </p>
                </div>
                <!-- End Email and Website -->
              </address>
            </div>
            <!-- End Footer Content -->
          </div>
        </div>
      </div>
      <!-- End Footer -->

      <!-- Copyright Footer -->
      <footer class="g-bg-gray-dark-v1 g-color-white-opacity-0_8 g-py-20">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8 text-center text-md-left g-mb-10 g-mb-0--md">
              <div class="d-lg-flex">
                <small class="d-block g-font-size-default g-mr-10 g-mb-10 g-mb-0--md">2017 © All Rights Reserved.</small>
                <ul class="u-list-inline">
                  <li class="list-inline-item">
                    <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Privacy Policy</a>
                  </li>
                  <li class="list-inline-item">
                    <span>|</span>
                  </li>
                  <li class="list-inline-item">
                    <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Terms of Use</a>
                  </li>
                  <li class="list-inline-item">
                    <span>|</span>
                  </li>
                  <li class="list-inline-item">
                    <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">License</a>
                  </li>
                  <li class="list-inline-item">
                    <span>|</span>
                  </li>
                  <li class="list-inline-item">
                    <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#">Support</a>
                  </li>
                </ul>
              </div>
            </div>

            <div class="col-md-4 align-self-center">
              <ul class="list-inline text-center text-md-right mb-0">
                <li class="list-inline-item g-mx-10" data-toggle="tooltip" data-placement="top" title="Facebook">
                  <a href="#" class="g-color-white-opacity-0_5 g-color-white--hover">
                    <i class="fa fa-facebook"></i>
                  </a>
                </li>
                <li class="list-inline-item g-mx-10" data-toggle="tooltip" data-placement="top" title="Skype">
                  <a href="#" class="g-color-white-opacity-0_5 g-color-white--hover">
                    <i class="fa fa-skype"></i>
                  </a>
                </li>
                <li class="list-inline-item g-mx-10" data-toggle="tooltip" data-placement="top" title="Linkedin">
                  <a href="#" class="g-color-white-opacity-0_5 g-color-white--hover">
                    <i class="fa fa-linkedin"></i>
                  </a>
                </li>
                <li class="list-inline-item g-mx-10" data-toggle="tooltip" data-placement="top" title="Pinterest">
                  <a href="#" class="g-color-white-opacity-0_5 g-color-white--hover">
                    <i class="fa fa-pinterest"></i>
                  </a>
                </li>
                <li class="list-inline-item g-mx-10" data-toggle="tooltip" data-placement="top" title="Twitter">
                  <a href="#" class="g-color-white-opacity-0_5 g-color-white--hover">
                    <i class="fa fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item g-mx-10" data-toggle="tooltip" data-placement="top" title="Dribbble">
                  <a href="#" class="g-color-white-opacity-0_5 g-color-white--hover">
                    <i class="fa fa-dribbble"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
      <!-- End Copyright Footer -->

      <a class="js-go-to u-go-to-v1" href="#"
         data-type="fixed"
         data-position='{
           "bottom": 15,
           "right": 15
         }'
         data-offset-top="400"
         data-compensation="#js-header"
         data-show-effect="zoomIn">
        <i class="hs-icon hs-icon-arrow-top"></i>
      </a>
    </main>

    <div id="modalMarkup" class="text-left modal-demo g-max-width-600 g-height-95x g-bg-white g-color-black g-pa-20" style="display: none;"></div>

    <!-- JS Global Compulsory -->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-migrate/jquery-migrate.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/tether.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/offcanvas.js"></script>

    <!-- JS Implementing Plugins -->
    <script src="<?php echo base_url();?>assets/vendor/hs-megamenu/src/hs.megamenu.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/dzsparallaxer/dzsparallaxer.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/dzsparallaxer/dzsscroller/scroller.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/dzsparallaxer/advancedscroller/plugin.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/gmaps/gmaps.min.js"></script>

    <!-- jQuery UI Core -->
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/widget.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/version.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/keycode.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/position.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/unique-id.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/safe-active-element.js"></script>
    <!-- End jQuery UI Core -->

    <!-- jQuery UI Helpers -->
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/widgets/menu.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/widgets/mouse.js"></script>
    <!-- End jQuery UI Helpers -->

    <!-- jQuery UI Widgets -->
    <script src="<?php echo base_url();?>assets/vendor/jquery-ui/ui/widgets/autocomplete.js"></script>
    <!-- End jQuery UI Widgets -->

    <!-- JS Unify -->
    <script src="<?php echo base_url();?>assets/js/hs.core.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/hs.header.js"></script>
    <script src="<?php echo base_url();?>assets/js/helpers/hs.hamburgers.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/hs.tabs.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/gmap/hs.map.js"></script>

    <!-- Show / Copy Code -->
    <script src="<?php echo base_url();?>assets/vendor/prism/prism.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/prism/components/prism-markup.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/prism/components/prism-css.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/prism/components/prism-clike.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/prism/components/prism-javascript.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/prism/plugins/toolbar/prism-toolbar.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/prism/plugins/copy-to-clipboard/prism-copy-to-clipboard.min.js"></script>

    <script src="<?php echo base_url();?>assets/vendor/malihu-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/custombox/custombox.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/clipboard/dist/clipboard.min.js"></script>

    <script src="<?php echo base_url();?>assets/js/components/hs.scrollbar.js"></script>
    <script src="<?php echo base_url();?>assets/js/helpers/hs.modal-markup.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/hs.markup-copy.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/hs.tabs.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/hs.modal-window.js"></script>
    <script src="<?php echo base_url();?>assets/js/helpers/hs.shortcode-filter.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/hs.autocomplete-local-search.js"></script>
    <script src="<?php echo base_url();?>assets/js/components/hs.go-to.js"></script>

    <script>
      $(document).on('ready', function () {
        $.HSCore.helpers.HSModalMarkup.init('.js-modal-markup');

        $.HSCore.components.HSMarkupCopy.init('.js-copy');
      });
    </script>

    <!-- JS Custom -->
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>

    <!-- JS Plugins Init -->
    <script>
      // initialization of google map
      function initMap() {
        $.HSCore.components.HSGMap.init('.js-g-map');
      }

      $(window).on('load', function () {
        // initialization of header
        $.HSCore.components.HSHeader.init($('#js-header'));
        $.HSCore.helpers.HSHamburgers.init('.hamburger');

        // initialization of autocomplet
        $.HSCore.components.HSLocalSearchAutocomplete.init('#autocomplete1');

        // initialization of go to
        $.HSCore.components.HSGoTo.init('.js-go-to');

        // initialization of HSMegaMenu plugin
        $('.js-mega-menu').HSMegaMenu({
          event: 'hover',
          pageContainer: $('.container'),
          breakpoint: 991
        });
      });
    </script>

  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAUupX2V6WfloENRmJqg-1Gl-bXEwdw3hY&callback=initMap"
  type="text/javascript"></script>
  </body>
</html>
