<!-- Team -->
<div class="container g-pt-100 g-pb-70">
  <div class="row justify-content-between">
    <div class="col-lg-6 g-mb-30">
      <em class="g-color-gray-light-v5 g-font-size-120 g-pos-abs g-top-minus-40 g-left-minus-15 g-z-index-minus-1">
          &#8220;
        </em>
      <h2 class="g-color-black g-font-weight-600 g-font-size-25 g-font-size-35--lg g-line-height-1_2 mb-4">Electrobras SRL</h2>
      <blockquote class="lead g-font-style-italic g-line-height-2 g-pl-30 g-mb-30">Somos una empresa líder de la Patagonia para la Patagonia dedicada a la venta de electricidad e iluminación para el hogar, comercio, e industria.</blockquote>
    </div>
    <div class="col-lg-5">
      <img class="img-fluid w-100" src="<?php echo base_url('assets/img/local.png') ?>" alt="Image Description">
      </iv>
    </div>
  </div>

  <hr class="g-brd-gray-light-v4 g-my-80">

  <div class="row justify-content-between">
    <div class="col-lg-5 g-mb-30">
      <img class="img-fluid w-100" src="<?php echo base_url('assets/img/example/electro_in_600x450.jpg');?>" alt="Image Description">
    </div>
    <div class="col-lg-6">
      <em class="g-color-gray-light-v5 g-font-size-120 g-pos-abs g-top-minus-40 g-left-minus-15 g-z-index-minus-1">
          &#8220;
        </em>
      <h2 class="g-color-black g-font-weight-600 g-font-size-25 g-font-size-35--lg g-line-height-1_2 mb-4">Más de 25 años en el mercado
      <blockquote class="lead g-font-style-italic g-line-height-2 g-pl-30 g-mb-30">Nuestro local totalmente remodelado cuenta con una superficie real de 900 mts2 de exposición y venta. Un depósito en dos niveles de 350 mts2 con permanente stock.<b>Personal capacitado e idóneo</b> para asesorar a quien lo requiera, una excelente atención personalizada. Incorporamos a nuestra línea de ventas Petit muebles, sillas, sillones, mesas, modulares y muchos productos mas para lograr ese toque de distinción que tanto buscaba.</blockquote>
    </div>
  </div>
</div>
<!-- End Team -->