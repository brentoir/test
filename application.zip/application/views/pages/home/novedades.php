<div class="container g-pt-100 g-pb-70">
	<h3 class="h2 g-font-weight-300 g-mb-20">Novedades</h3>
	<a href="<?php echo base_url('index.php/Electrobras/NuevaNovedad');?>" class="btn btn-md u-btn-inset u-btn-blue g-mr-10 g-mb-15">Nueva novedad</a>
	<div class="row col-sm-12">
		  <div class="col-md-6 g-mb-30">
		    <a class="js-fancybox" data-fancybox-gallery="lightbox-gallery--col2" href="<?php echo base_url('assets/img/novedades/nov01b.jpg');?>" title="Ahorra mas tiempo">
		      <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/nov01b.jpg');?>" alt="Image Description">
		    </a>
		  </div>
		  <div class="col-md-6 g-mb-30">
		    <a class="js-fancybox" data-fancybox-gallery="lightbox-gallery--col2" href="<?php echo base_url('assets/img/novedades/nov02b.jpg');?>" title="Asesoramiento en obra">
		      <img class="img-fluid" src="<?php echo base_url('assets/img/novedades/nov02b.jpg');?>" alt="Image Description">
		    </a>
		  </div>  
	</div>




  <!-- News Section -->
  <div class="u-heading-v3-1 g-mb-30">
    <h2 class="h5 u-heading-v3__title g-color-gray-dark-v1 text-uppercase g-brd-primary">Ultimas novedades</h2>
  </div>

  <div class="row g-mb-70">
    <div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/example/example02.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!">Titulo</a></h3>
          <p class="g-font-size-13">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec.</p>

          <hr class="g-brd-secondary-light-v2 my-3">


        </div>
      </article>
      <!-- End Article -->
    </div>

    <div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/example/example01.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!">Titulo</a></h3>
          <p class="g-font-size-13">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec.</p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>

    <div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/example/example03.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!">Titulo</a></h3>
          <p class="g-font-size-13">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec.</p>

          <hr class="g-brd-secondary-light-v2 my-3">


        </div>
      </article>
      <!-- End Article -->
    </div>
  </div>
  <!-- End News Section -->

</div>