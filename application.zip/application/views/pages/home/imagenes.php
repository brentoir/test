    <!-- Cube Portfolio Blocks -->
    <section class="container g-py-100">
      <div class="g-mb-50">
        <div class="d-flex justify-content-start g-brd-bottom g-brd-gray-light-v4 pb-5">
          <div class="d-block">
            <h2 class="h1 g-color-black">Imágenes de nuestros productos</h2>
          </div>
        </div>
      </div>
      <div>
        <a href="<?php echo base_url('index.php/Electrobras/New_image')?>" class="btn btn-success"> Subir imagen </a>
      </div>
      <hr>
      <!-- Cube Portfolio Blocks - Filter -->
      <ul id="filterControls1" class="d-block list-inline g-mb-50">
        <li class="list-inline-item cbp-filter-item g-color-black g-color-gray-dark-v5--active g-font-weight-600 g-font-size-13 text-uppercase pr-2 mb-2" role="button" data-filter="*">
          Ver todos
        </li>
        <li class="list-inline-item cbp-filter-item g-color-black g-color-primary--hover g-color-gray-dark-v5--active g-font-weight-600 g-font-size-13 text-uppercase px-2 mb-2" role="button" data-filter=".identity">
          Identity
        </li>
        <li class="list-inline-item cbp-filter-item g-color-black g-color-primary--hover g-color-gray-dark-v5--active g-font-weight-600 g-font-size-13 text-uppercase px-2 mb-2" role="button" data-filter=".design">
          Design
        </li>
        <li class="list-inline-item cbp-filter-item g-color-black g-color-primary--hover g-color-gray-dark-v5--active g-font-weight-600 g-font-size-13 text-uppercase px-2 mb-2" role="button" data-filter=".graphic">
          Graphic
        </li>
        <li class="list-inline-item cbp-filter-item g-color-black g-color-primary--hover g-color-gray-dark-v5--active g-font-weight-600 g-font-size-13 text-uppercase g-letter-spacing-0_5 px-2 mb-2" role="button" data-filter=".graphic, .identity">
          Design &amp; Identity
        </li>
      </ul>
      <!-- End Cube Portfolio Blocks - Filter -->

      <!-- Cube Portfolio Blocks - Content -->
      <div class="cbp" data-controls="#filterControls1" data-animation="quicksand" data-x-gap="30" data-y-gap="30" data-media-queries='[{"width": 1500, "cols": 3}, {"width": 1100, "cols": 3}, {"width": 800, "cols": 3}, {"width": 480, "cols": 2}, {"width": 300, "cols": 1}]'>
        <!-- Cube Portfolio Blocks - Item -->
        <div id="shortcode" class="cbp-item identity design">
          <div class="u-block-hover g-parent">
            <img class="img-fluid g-transform-scale-1_1--parent-hover g-transition-0_5 g-transition--ease-in-out" src="../../assets/img-temp/400x270/img8.jpg" alt="Image description">
            <div class="d-flex w-100 h-100 u-block-hover__additional--fade u-block-hover__additional--fade-in g-pos-abs g-top-0 g-left-0 g-transition-0_3 g-transition--ease-in g-pa-20">
              <ul class="align-items-end flex-column list-inline mt-auto ml-auto mb-0">
                <li class="list-inline-item">
                  <a class="u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="#">
                    <i class="icon-communication-095 u-line-icon-pro"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="cbp-lightbox u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="../../assets/img-temp/400x270/img8.jpg">
                    <i class="icon-communication-017 u-line-icon-pro"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="text-center g-pa-25">
            <h3 class="h5 g-color-black mb-1">Branding work</h3>
            <p class="g-color-gray-dark-v4 mb-0">Identity, Design</p>
          </div>
        </div>
        <!-- End Cube Portfolio Blocks - Item -->

        <!-- Cube Portfolio Blocks - Item -->
        <div class="cbp-item design">
          <div class="u-block-hover g-parent">
            <img class="img-fluid g-transform-scale-1_1--parent-hover g-transition-0_5 g-transition--ease-in-out" src="../../assets/img-temp/400x270/img9.jpg" alt="Image description">
            <div class="d-flex w-100 h-100 u-block-hover__additional--fade u-block-hover__additional--fade-in g-pos-abs g-top-0 g-left-0 g-transition-0_3 g-transition--ease-in g-pa-20">
              <ul class="align-items-end flex-column list-inline mt-auto ml-auto mb-0">
                <li class="list-inline-item">
                  <a class="u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="#">
                    <i class="icon-communication-095 u-line-icon-pro"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="cbp-lightbox u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="../../assets/img-temp/400x270/img9.jpg">
                    <i class="icon-communication-017 u-line-icon-pro"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="text-center g-pa-25">
            <h3 class="h5 g-color-black mb-1">Development</h3>
            <p class="g-color-gray-dark-v4 mb-0">Design</p>
          </div>
        </div>
        <!-- End Cube Portfolio Blocks - Item -->

        <!-- Cube Portfolio Blocks - Item -->
        <div class="cbp-item graphic identity">
          <div class="u-block-hover g-parent">
            <img class="img-fluid g-transform-scale-1_1--parent-hover g-transition-0_5 g-transition--ease-in-out" src="../../assets/img-temp/400x270/img2.jpg" alt="Image description">
            <div class="d-flex w-100 h-100 u-block-hover__additional--fade u-block-hover__additional--fade-in g-pos-abs g-top-0 g-left-0 g-transition-0_3 g-transition--ease-in g-pa-20">
              <ul class="align-items-end flex-column list-inline mt-auto ml-auto mb-0">
                <li class="list-inline-item">
                  <a class="u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="#">
                    <i class="icon-communication-095 u-line-icon-pro"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="cbp-lightbox u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="../../assets/img-temp/400x270/img2.jpg">
                    <i class="icon-communication-017 u-line-icon-pro"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="text-center g-pa-25">
            <h3 class="h5 g-color-black mb-1">Project planner</h3>
            <p class="g-color-gray-dark-v4 mb-0">Graphic, Identity</p>
          </div>
        </div>
        <!-- End Cube Portfolio Blocks - Item -->

        <!-- Cube Portfolio Blocks - Item -->
        <div class="cbp-item graphic">
          <div class="u-block-hover g-parent">
            <img class="img-fluid g-transform-scale-1_1--parent-hover g-transition-0_5 g-transition--ease-in-out" src="../../assets/img-temp/400x270/img11.jpg" alt="Image description">
            <div class="d-flex w-100 h-100 u-block-hover__additional--fade u-block-hover__additional--fade-in g-pos-abs g-top-0 g-left-0 g-transition-0_3 g-transition--ease-in g-pa-20">
              <ul class="align-items-end flex-column list-inline mt-auto ml-auto mb-0">
                <li class="list-inline-item">
                  <a class="u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="#">
                    <i class="icon-communication-095 u-line-icon-pro"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="cbp-lightbox u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="../../assets/img-temp/400x270/img11.jpg">
                    <i class="icon-communication-017 u-line-icon-pro"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="text-center g-pa-25">
            <h3 class="h5 g-color-black mb-1">Design</h3>
            <p class="g-color-gray-dark-v4 mb-0">Graphic</p>
          </div>
        </div>
        <!-- End Cube Portfolio Blocks - Item -->

        <!-- Cube Portfolio Blocks - Item -->
        <div class="cbp-item identity">
          <div class="u-block-hover g-parent">
            <img class="img-fluid g-transform-scale-1_1--parent-hover g-transition-0_5 g-transition--ease-in-out" src="../../assets/img-temp/400x270/img12.jpg" alt="Image description">
            <div class="d-flex w-100 h-100 u-block-hover__additional--fade u-block-hover__additional--fade-in g-pos-abs g-top-0 g-left-0 g-transition-0_3 g-transition--ease-in g-pa-20">
              <ul class="align-items-end flex-column list-inline mt-auto ml-auto mb-0">
                <li class="list-inline-item">
                  <a class="u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="#">
                    <i class="icon-communication-095 u-line-icon-pro"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="cbp-lightbox u-icon-v2 u-icon-size--sm g-brd-white g-color-black g-bg-white rounded-circle" href="../../assets/img-temp/400x270/img12.jpg">
                    <i class="icon-communication-017 u-line-icon-pro"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="text-center g-pa-25">
            <h3 class="h5 g-color-black mb-1">Creative agency</h3>
            <p class="g-color-gray-dark-v4 mb-0">Identity</p>
          </div>
        </div>
        <!-- End Cube Portfolio Blocks - Item -->

        <!-- Cube Portfolio Blocks - Item -->
        <div class="cbp-item graphic">
          <div class="u-block-hover g-parent">
            <a class="cbp-lightbox" data-title="custom title 1" href="../../assets/img-temp/400x270/img8.jpg">
              <img src="../../assets/img-temp/400x270/img8.jpg" alt="custom alt 1" width="100%">
            </a>
          </div>
        </div>
        <!-- End Cube Portfolio Blocks - Item -->
      </div>
      <!-- End Cube Portfolio Blocks - Content -->
    </section>
    <!-- End Cube Portfolio Blocks -->