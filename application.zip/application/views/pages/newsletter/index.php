<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<h1> Newsletter </h1>
		</div>
	</div>

	<div class="g-ml-2">
		<a href="<?php echo base_url('index.php/Newsletter/new');?>" class="btn btn-md u-btn-inset u-btn-blue g-mr-10 g-mb-15">Enviar correo</a>
	</div>
  <!-- Hover Rows -->
  <div class="card g-brd-blue rounded-0 g-mb-30">
    <h3 class="card-header g-bg-blue g-brd-transparent g-color-white g-font-size-16 rounded-0 mb-0">
      <i class="fa fa-gear g-mr-5"></i>
      Lista de correos registrados
    </h3>

    <div class="table-responsive">
      <table id="newsletter_table" class="table table-hover u-table--v1 mb-0 w-100">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Autorizado</th>
            <th>Acciones</th>
          </tr>
        </thead>

        <tbody>
          <!-- Ajax -->
        </tbody>
      </table>
    </div>
  </div>
  <!-- End Hover Rows -->
</div>


<div class="modal fade" id="modal_delete_newletter" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">¿ Esta seguro de eliminar este correo este correo ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <input type="hidden" id="newletter_delete_id" name="newletter_delete_id" value="">
					<button type="submit" class="btn u-btn-red" onclick="destroy()">Eliminar</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">
  var  newsletter_table

  function modal_delete( id )
  {
    $('#newletter_delete_id').val( id )
    $('#error-motivo').text('')
    $('#modal_delete_newletter').modal('show')
  }

  function destroy()
  {
    $.ajax({
      url: '<?php echo base_url("index.php/Newsletter/destroy");?>',
      type: 'POST',
      data: { id: $('#newletter_delete_id').val() },
      success: function(resp)
      {
        if (resp === 'ok') {
          window.location.href = "<?php echo base_url('index.php/Newsletter/admin');?>"
        } else {
          noty_alert( 'error' , 'Error al eliminar la novedad')
        }
      },
      error: function()
      {
        noty_alert( 'error' , 'Error al eliminar la novedad')
      }
    })
  } // End destroy method

  function change_active( email_id )
  {
    $.ajax({
      url: '<?php echo base_url("index.php/Newsletter/change_active");?>',
      type: 'POST',
      data: { id: email_id },
      success: function(resp)
      {
        if (resp === 'ok') {
          newsletter_table.ajax.reload(null,false)
        } else {
          noty_alert( 'error' , 'Error al cambiar estado')
        }
      },
      error: function()
      {
        noty_alert( 'error' , 'Error al cambiar estado')
      }
    })
  }

	$(document).on('ready', function () {
		newsletter_table = $('#newsletter_table').DataTable({
                                ajax: '<?php echo base_url("index.php/Newsletter/ajax_list_emails") ?>',
                          			language: { url: "<?php echo base_url('assets/vendor/datatables/spanish.json');?>" }
                          		})
	})
</script>