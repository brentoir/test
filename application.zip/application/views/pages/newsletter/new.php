<div class="container">
	<h1>Formulario de envio de correos masivos</h1>

	<?php echo form_open_multipart('Newsletter/create', 
							array( 'id'=>'form_new_image','class'=>'g-brd-around g-brd-gray-light-v4 g-pa-30 g-mb-30', 'method' => 'post'));?>
		<div class="form-group g-mb-20">
			<!-- Input numero interno -->
		  <div class="form-group g-mb-10">
		    <label class="col-sm-4 col-md-4 col-lg-2 col-form-label g-mb-10" for="subject">Asunto (*)</label>
		    <div id="input_title" class="col-sm-8">
		      <input id="subject" name="subject" class="form-control u-form-control rounded-0" type="text"  value=""> 
		    </div>
		  </div>
		  <!-- End Input numero interno -->
		  <!-- Textarea Input with Left Appended Icon -->
		  <div class="form-group g-mb-20">
		    <label class="g-mb-10">Contenido</label>
		    <div class="input-group g-brd-primary--focus">
		      <textarea id="message" name="message" class="form-control form-control-md g-resize-none rounded-0" rows="4" placeholder="Ingrese un texto para la novedad"></textarea>
		    </div>
		  </div>
		  <!-- End Textarea Input with Left Appended Icon -->
		  <!-- Plain File Input -->
		  <div class="form-group mb-0">
		    <p>Click para subir imagen</p>
		    <label class="u-file-attach-v2 g-color-gray-dark-v5 mb-0">
		      <input id="imagefile" name="imagefile" type="file" required>
		      <i class="icon-cloud-upload g-font-size-16 g-pos-rel g-top-2 g-mr-5"></i>
		      <span class="js-value">Subir imagen</span>
					<?php if ($error_imagen != null): ?>
						<small class="form-control-feedback"><?php echo $error_imagen ?></small>
					<?php endif ?>
		    </label>
		  </div>
		  <!-- End Plain File Input -->
		</div>
		<button type="submit" class="btn btn-md u-btn-inset u-btn-indigo g-mr-10 g-mb-15">Enviar correo</button>
		<a href="<?php echo base_url('index.php/Newsletter');?>" class="btn btn-md u-btn-inset u-btn-red g-mr-10 g-mb-15">Cancelar</a>
	</form>
</div>