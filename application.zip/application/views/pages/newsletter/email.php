<div>
	<p> <?php echo $data->message ?> </p>
	<br>
</div>
<div>
	<img src="<?php echo base_url('assets/img/newsletters/').$data->img ?>">
</div>