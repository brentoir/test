<div class="container">
	<h1>Llene el siguiente formulario para subir una imágen</h1>
		<?php echo form_open_multipart('Galeria/create', array( 'id'=>'form_new_image','class'=>'g-brd-around g-brd-gray-light-v4 g-pa-30 g-mb-30', 'method' => 'post'));?>
			<div class="form-group g-mb-20">
				<!-- Input name image -->
<!-- 			  <div class="form-group row g-mb-10">
			    <label class="col-sm-2 col-form-label g-mb-10" for="interno">Nombre</label>
			    <div id="input_interno" class="col-sm-9">
			      <input id="name" name="name" class="form-control u-form-control rounded-0" placeholder="Ingrese nombre imagen" type="text"  value="" required> 
			    </div>
			  </div> -->
			  <!-- End Input name image -->

			  <div class="form-group row g-mb-10">
			    <label class="col-sm-2 col-form-label g-mb-10" for="select_categories">Seleccione categoria</label>
			    <select class="form-control rounded-0 col-sm-6" id="select_categories" >
			      <option value="" disabled selected>Seleccione categoria</option>
			      <!-- ajax -->
			    </select>
			     <button type="button" class="btn btn-sm u-btn-cyan u-btn-inset g-ml-5" data-toggle="modal" data-target="#modal_categorias">
	          Admin categorias
	        </button>
			  </div>

				<!-- Input categories image -->
			  <div class="form-group row g-mb-10">
			    <div id="input_interno" class="col-sm-9">
			      <input id="categories_image" name="categories_image" class="form-control u-form-control rounded-0" 
			      			 type="text"  value="" data-role="tagsinput" required> 
			    </div>
			  </div>
			  <!-- End Input categories image -->

			  <!-- Plain File Input -->
			  <div class="form-group mb-0">
			    <p>Click para subir imagen</p>
			    <label class="u-file-attach-v2 g-color-gray-dark-v5 mb-0">
			      <input id="imagefile" name="imagefile" type="file">
			      <i class="icon-cloud-upload g-font-size-16 g-pos-rel g-top-2 g-mr-5"></i>
			      <span class="js-value">Subir imagen</span>
			    </label>
			  </div>
			  <!-- End Plain File Input -->

			</div>
			<button type="submit" class="btn btn-md u-btn-inset u-btn-indigo g-mr-10 g-mb-15">Subir</button>

			<a href="<?php echo base_url('index.php/Galeria');?>" class="btn btn-md u-btn-inset u-btn-red g-mr-10 g-mb-15">Cancelar</a>
	</form>
</div>


<!-- Modal -->
<div class="modal fade" id="modal_categorias" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Categorias de imagenes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form id="form_new_category" action="" class="g-brd-around g-brd-gray-light-v4 g-pa-15 g-mb-15">
      		<label> Nombre </label>
      		<input type="text" id="name_new_category" name="name_new_category" required>
      		<button type="submit" id="btn_save_category" class="btn u-btn-sm u-btn-primary"> Agregar categoria </button>
      		<br>
      		<div id="alert-msg-category" class="alert-msg"></div>
      	</form>

        <div class="table-responsive">
          <table id="tabla_categoria_imagenes" class="table table-hover w-100">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              <!-- populate with ajax -->
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn u-btn-red u-btn-inset" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modal_delete_category" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">¿ Esta seguro de eliminar esta categoria ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <input type="hidden" id="category_delete_id" name="category_delete_id" value="">
					<button type="submit" class="btn u-btn-red" onclick="destroy_category()">Eliminar</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
	var tabla_categoria_imagenes

	function print_categories( )
	{
		$.ajax({
			url: "<?php echo base_url('index.php/Galeria/get_categories') ?>",
			type: 'GET',
			success: function(resp){
				var attr_vehiculo = $.parseJSON(resp)

					$('#select_categories').find('option').remove().end().append('<option value="" disabled selected >Seleccione categoria </option>')
					$(attr_vehiculo).each(function(i, element){
						$('#select_categories').append("<option value="+element.id+">"+element.name+"</option>");
					});
			},
			error: function(jqXHR, textStatus, errorThrown){
				$('#select_categories').find('option').remove().end().append('<option value="" disabled selected >Seleccione categoria</option>');
				$('#select_categories').append("<option>No se pudieron obtener las categorias</option>");
			}
		})
	}

	function modal_delete_category( id )
	{
		$('#category_delete_id').val( id )
		$('#modal_delete_category').modal('show')
	}

  function destroy_category()
  {
    $.ajax({
      url: '<?php echo base_url("index.php/Galeria/destroy_category");?>',
      type: 'POST',
      data: { id: $('#category_delete_id').val() },
      success: function(resp)
      {
        if (resp === 'ok') {
          noty_alert( 'success' , 'Categoria eliminada')
          print_categories( )
					tabla_categoria_imagenes.ajax.reload(null,false)
					$('#modal_delete_category').modal('hide')
        } else {
          noty_alert( 'error' , 'Error al eliminar la categoria')
        }
      },
      error: function()
      {
        noty_alert( 'error' , 'Error al eliminar la categoria')
      }
    })
  } // End destroy method
	print_categories( )


$( "#select_categories" ).change(function() {
  $('#categories_image').tagsinput('add', $( "#select_categories option:selected" ).text() )
})

	$(document).on('ready', function () {

		var form_new_category = $('#form_new_category').validate({
																	rules: {
																		'name_new_category': { 
																			required: true,
																			remote: {
						                            url: "<?php echo base_url('index.php/Galeria/validate_category_name');?>",
						                            type: "POST",
						                            data: {
						                              name: function() {
						                                return $('#name_new_category').val()
						                              }
						                            }
						                          }	},
																	},
																	messages: {
							                        'name_new_category' : {
							                          remote: 'La categoria ya existe'
							                        }
							                      }
																})

		$('#form_new_category').submit(function(e){
			e.preventDefault()
			if ( form_new_category.valid() ) {
				$('#btn_save_category').prop( "disabled", true )
				$('#btn_save_category').text('Grabando...')

				$.ajax({
					url: "<?php echo base_url('index.php/Galeria/create_category');?>",
					type: 'POST',
					cache: false,
					data: { name: $('#name_new_category').val() },
					success: function(msg){
						if (msg === 'success') {
							print_categories( )
							tabla_categoria_imagenes.ajax.reload(null,false)
							$('#btn_save_category').text('Agregar categoria')
							$('#btn_save_category').prop( "disabled", false )
							$('#form_new_category')[0].reset()
						} else {
							$('#btn_save_category').text('Agregar categoria')
							$('#btn_save_category').prop( "disabled", false )
							noty_alert( 'error' , 'No se pudo generar la categoria' )
						}
					},
					error: function(jqXHR, textStatus, errorThrown){
						noty_alert( 'error' , 'No se pudo generar la categoria' )
					}
				})
			}
		})


		tabla_categoria_imagenes = $('#tabla_categoria_imagenes').DataTable({
																	ajax: "<?php echo base_url('index.php/Galeria/ajax_list_categories') ?>",
																	language: { url: "<?php echo base_url('assets/vendor/datatables/spanish.json');?>" }
																})
	})

</script>