   <div class="container">
  <div class="row">
    <div class="u-shadow-v1-3 g-line-height-2 g-pa-40 g-mb-30" role="alert">
      <h3 class="h2 g-font-weight-300 g-mb-20">Productos</h3>
      <p class="mb-0">A continuación proporcionamos un listado de imágenes, a modo ilustrativo, de los diversos productos que usted puede adquirir en nuestro local comercial.</p>
    </div>
    
  </div>
</div>
   


<!-- Cubeportfolio -->
    <section class="container g-py-100">

      <!-- Cubeportfolio Filter -->
      <ul id="filterControls" class="text-center u-filter-v1 g-mb-40">
        <li class="list-inline-item cbp-filter-item cbp-filter-item-active g-cursor-pointer g-transition-0_2" data-filter="*">Ver todas</li>
        <li class="list-inline-item cbp-filter-item text-uppercase g-cursor-pointer g-transition-0_2" data-filter=".js-illustration">Muebles</li>
        <li class="list-inline-item cbp-filter-item text-uppercase g-cursor-pointer g-transition-0_2" data-filter=".js-design">Iluminación</li>
        <li class="list-inline-item cbp-filter-item text-uppercase g-cursor-pointer g-transition-0_2" data-filter=".js-graphic">Interior</li>
        <li class="list-inline-item cbp-filter-item text-uppercase g-cursor-pointer g-transition-0_2" data-filter=".js-logo">Seguridad</li>
      </ul>
      <!-- End Cubeportfolio Filter -->

      <!-- Cubeportfolio container -->
      <div class="cbp" data-controls="#filterControls">
       
          <div class="cbp-item js-illustration">
          <!-- Figure -->
            <div class="u-block-hover g-parent">
              <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb1.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb1.jpg') ?>" alt="Image Description">
              </a>
               <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb2.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb2.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb3.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb3.jpg') ?>" alt="Image Description">
              </a> 
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb4.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb4.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb5.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb5.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb6.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb6.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb7.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb7.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb8.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb8.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb9.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb9.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb10.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/muebles/mueb10.jpg') ?>" alt="Image Description">
              </a>
            </div>
          <!-- End Figure -->
        </div>

   <div class="cbp-item js-design">
          <!-- Figure -->
            <div class="u-block-hover g-parent">
              <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum1.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum1.jpg') ?>" alt="Image Description">
              </a>
               <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum2.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum2.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum3.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum3.jpg') ?>" alt="Image Description">
              </a> 
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum4.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum4.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum5.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum5.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum6.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum6.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum7.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum7.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum8.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum8.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum9.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum9.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum10.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum10.jpg') ?>" alt="Image Description">
              </a>
                 <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum11.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum11.jpg') ?>" alt="Image Description">
              </a>
                 <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum12.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum12.jpg') ?>" alt="Image Description">
              </a>
                 <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum13.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum13.jpg') ?>" alt="Image Description">
              </a>
                 <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum14.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum14.jpg') ?>" alt="Image Description">
              </a>
                 <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum15.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/iluminacion/ilum15.jpg') ?>" alt="Image Description">
              </a>
            </div>
          <!-- End Figure -->
        </div>
       
          <div class="cbp-item js-graphic">
          <!-- Figure -->          
            <div class="u-block-hover g-parent">
              <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter1.jpg') ?>">
                  <div>
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter1.jpg') ?>" alt="Image Description">
                  </div>
              </a>
               <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter2.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter2.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter3.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter3.jpg') ?>" alt="Image Description">
              </a> 
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter4.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter4.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter5.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter5.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter6.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter6.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter7.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter7.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter8.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter8.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter9.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter9.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/interior/inter10.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/interior/inter10.jpg') ?>" alt="Image Description">
              </a>
                
            </div>
                
          <!-- End Figure -->
        </div>

           <div class="cbp-item js-logo">
          <!-- Figure -->
            <div class="u-block-hover g-parent list-inline-item">
              <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu8.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu8.jpg') ?>" alt="Image Description">
              </a>
               <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu7.jpg') ?>">
                <img  src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu7.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu4.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu4.jpg') ?>" alt="Image Description">
              </a> 
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu10.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu10.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu5.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu5.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu1.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu1.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu9.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu9.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu6.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu6.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu2.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu2.jpg') ?>" alt="Image Description">
              </a>
                <a class="cbp-lightbox" href="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu3.jpg') ?>">
                <img src="<?php echo base_url('assets/img/productos/imagenes/seguridad/segu3.jpg') ?>" alt="Image Description">
              </a>
            </div>
          <!-- End Figure -->
        </div>
       
      </div>
      <!-- End Cubeportfolio container -->
    </section>
    <!-- End Cubeportfolio -->

<div class="modal fade" id="modal_delete_img" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">¿ Esta seguro de eliminar esta imagen ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <input type="hidden" id="img_delete_id" name="img_delete_id" value="">
          <button type="submit" class="btn u-btn-red g-mt-2" onclick="destroy()">Eliminar</button>
          <button type="button" class="btn btn-secondary g-mt-2" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>



<script type="text/javascript">
  function modal_delete( id )
  {
    $('#img_delete_id').val( id )
    $('#error-motivo').text('')
    $('#modal_delete_img').modal('show')
  }

  function destroy()
  {
    $.ajax({
      url: '<?php echo base_url("index.php/Galeria/destroy");?>',
      type: 'POST',
      data: { id: $('#img_delete_id').val() },
      success: function(resp)
      {
        if (resp === 'ok') {
          window.location.href = "<?php echo base_url('index.php/Galeria');?>"
        } else {
          noty_alert( 'error' , 'Error al eliminar la imagen')
        }
      },
      error: function()
      {
        noty_alert( 'error' , 'Error al eliminar la imagen')
      }
    })
  } // End destroy method

  $(document).on('ready', function () {
    $('#news_table').DataTable({
      language: { url: "<?php echo base_url('assets/vendor/datatables/spanish.json');?>" }
    })
  })
</script>