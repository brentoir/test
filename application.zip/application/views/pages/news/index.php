<div class="container g-pt-100 g-pb-70">
  <a href="<?php echo base_url('index.php/Novedades/new');?>" class="btn btn-md u-btn-inset u-btn-teal g-mr-10 g-mb-15">Agregar novedad</a>
	<!-- <a href="<?php echo base_url('index.php/Novedades/admin');?>" class="btn btn-md u-btn-inset u-btn-blue g-mr-10 g-mb-15">Administrar novedades</a> -->
  <!-- News Section -->
  <div class="u-heading-v3-1 g-mb-30">
    <h2 class="h5 u-heading-v3__title g-color-gray-dark-v1 text-uppercase g-brd-primary">Ultimas novedades</h2>
  </div>

 
     <div class="row g-mb-5">
    <div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->

      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example02.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <div class="row">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!">Cámaras de seguridad</a></h3>
          </div>

          <p class="g-font-size-13">Te asesoramos en la compra de lo necesario para que tu casa sea segura y puedas vivir tranquilo. Tecnología de primera calidad en la puerta de tu casa. </p>
          <hr class="g-brd-secondary-light-v2 my-3">
        </div>
      </article>
      <!-- End Article -->

    </div>

    <div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example01.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!">Por un futuro más limpio</a></h3>
          <p class="g-font-size-13">Participamos en el cuidado del medio ambiente, generando conciencia ecológica en nuestros clientes.</p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>

    <div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example03.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!">MercadoPago</a></h3>
          <p class="g-font-size-13">A partir de ahora, los clientes de Electrobras podrán abonar desde su celular con MercadoPago: la nueva plataforma de beneficios.</p>

          <hr class="g-brd-secondary-light-v2 my-3">


        </div>
      </article>
      <!-- End Article -->
    </div>

<div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example04.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!"> Petit Muebles</a></h3>
          <p class="g-font-size-13"> Participamos en el cuidado del medio ambiente, generando conciencia ecológica en nuestras clientes. </p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>

<div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example05.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!"> Energía renovable </a></h3>
          <p class="g-font-size-13"> Luminarias alimentadas con energía solar </p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>

<div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example06.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!"> Asesoramiento personalizado</a></h3>
          <p class="g-font-size-13"> Participamos en el cuidado del medio ambiente, generando conciencia ecológica en nuestras clientes. </p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>

<div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example07.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!"> Asesoramiento en obra</a></h3>
          <p class="g-font-size-13"> Participamos en el cuidado del medio ambiente, generando conciencia ecológica en nuestras clientes. </p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>

<div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example08.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!"> Iluminación</a></h3>
          <p class="g-font-size-13"> Participamos en el cuidado del medio ambiente, generando conciencia ecológica en nuestras clientes. </p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>
      
      <div class="col-sm-6 col-lg-4 g-mb-30">
      <!-- Article -->
      <article>
        <img class="img-fluid w-100" src="<?php echo base_url('assets/img/novedades/example09.jpg');?>" alt="Image Description">

        <div class="g-brd-around g-brd-secondary-light-v2 g-bg-white g-pa-20">
          <h3 class="g-font-size-16"><a class="u-link-v5 g-color-main g-color-primary--hover" href="#!"> Electricidad</a></h3>
          <p class="g-font-size-13"> Participamos en el cuidado del medio ambiente, generando conciencia ecológica en nuestras clientes. </p>

          <hr class="g-brd-secondary-light-v2 my-3">

        </div>
      </article>
      <!-- End Article -->
    </div>
      

        

  



<div class="modal fade" id="modal_delete_new" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">¿ Esta seguro de eliminar esta novedad ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <input type="hidden" id="new_delete_id" name="new_delete_id" value="">
          <button type="submit" class="btn u-btn-red" onclick="destroy()">Eliminar</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">
  function modal_delete( id )
  {
    $('#new_delete_id').val( id )
    $('#error-motivo').text('')
    $('#modal_delete_new').modal('show')
  }

  function destroy()
  {
    $.ajax({
      url: '<?php echo base_url("index.php/Novedades/destroy");?>',
      type: 'POST',
      data: { id: $('#new_delete_id').val() },
      success: function(resp)
      {
        if (resp === 'ok') {
          window.location.href = "<?php echo base_url('index.php/Novedades');?>"
        } else {
          noty_alert( 'error' , 'Error al eliminar la novedad')
        }
      },
      error: function()
      {
        noty_alert( 'error' , 'Error al eliminar la novedad')
      }
    })
  } // End destroy method

  $(document).on('ready', function () {
    $('#news_table').DataTable({
      language: { url: "<?php echo base_url('assets/vendor/datatables/spanish.json');?>" }
    })
  })
</script>