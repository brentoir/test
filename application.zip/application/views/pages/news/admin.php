<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<h1> Administracion de novedades </h1>
		</div>
	</div>

	<div class="g-ml-2">
		<a href="<?php echo base_url('index.php/Novedades/new');?>" class="btn btn-md u-btn-inset u-btn-blue g-mr-10 g-mb-15">Nueva novedad</a>
	</div>
  <!-- Hover Rows -->
  <div class="card g-brd-blue rounded-0 g-mb-30">
    <h3 class="card-header g-bg-blue g-brd-transparent g-color-white g-font-size-16 rounded-0 mb-0">
      <i class="fa fa-gear g-mr-5"></i>
      Novedades registradas
    </h3>

    <div class="table-responsive">
      <table id="news_table" class="table table-hover u-table--v1 mb-0">
        <thead>
          <tr>
            <th>#</th>
            <th>Fecha</th>
            <th class="hidden-sm">Titulo</th>
            <th>Detalle</th>
            <th>Acciones</th>
          </tr>
        </thead>

        <tbody>
          <?php foreach ($news as $n): ?>
          	<tr>
          		<td> <?php echo $n->id ?> </td>
          		<td> <?php echo date('d-m-Y', strtotime($n->created_at)) ?> </td>
          		<td> <?php echo $n->title ?> </td>
          		<td> <?php echo $n->content ?> </td>
          		<td> 
          			<a class="btn btn-sm u-btn-orange" 
          					href="<?php echo base_url('index.php/Novedades/edit/').$n->id;?>"> 
          					<i class="fa fa-edit"></i> 
          			</a> 
                <button class="btn btn-sm u-btn-red g-mr-5"
		              title="Eliminar"
		              onclick="modal_delete('<?php echo $n->id;?>')">
		              <i class="fa fa-trash-o"></i>
                </button>
          		</td>
          	</tr>
          <?php endforeach ?>
        </tbody>
      </table>
    </div>
  </div>
  <!-- End Hover Rows -->
</div>


<div class="modal fade" id="modal_delete_new" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">¿ Esta seguro de eliminar esta novedad ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <input type="hidden" id="new_delete_id" name="new_delete_id" value="">
					<button type="submit" class="btn u-btn-red" onclick="destroy()">Eliminar</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">
  function modal_delete( id )
  {
    $('#new_delete_id').val( id )
    $('#error-motivo').text('')
    $('#modal_delete_new').modal('show')
  }

  function destroy()
  {
    $.ajax({
      url: '<?php echo base_url("index.php/Novedades/destroy");?>',
      type: 'POST',
      data: { id: $('#new_delete_id').val() },
      success: function(resp)
      {
        if (resp === 'ok') {
          window.location.href = "<?php echo base_url('index.php/Novedades/admin');?>"
        } else {
          noty_alert( 'error' , 'Error al eliminar la novedad')
        }
      },
      error: function()
      {
        noty_alert( 'error' , 'Error al eliminar la novedad')
      }
    })
  } // End destroy method

	$(document).on('ready', function () {
		$('#news_table').DataTable({
			language: { url: "<?php echo base_url('assets/vendor/datatables/spanish.json');?>" }
		})
	})
</script>