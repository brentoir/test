<?php

class New_model extends CI_Model {

  function __construct()
  {
    parent::__construct();
  }

  function get($attr = null, $valor = null)
  {
  	if($attr != null and $valor != null) {
  		$query = $this->db->select('*')
                          ->from('news')
                            ->where('news.'.$attr, $valor)
                              ->order_by('id','DESC')
                                ->get();
      return $query->result();
  	} else {
    		return $this->db->get_where('news', array('active' => true))->result();
    	}
  }

  function insert_entry( $entry )
  {
  	return $this->db->insert( 'news', $entry );
  }

  function update_entry($id, $entry)
  {
    $this->db->where('id', $id);
    return $this->db->update('news', $entry);
  }

  function destroy( $id )
  {
    $entry = $this->db->get_where('news', array('id' => $id))->row();
    $entry->active = false;

    $this->db->where('id', $id);
    return $this->db->update('news', $entry);
  }

  function get_last_id()
  {
    $query = $this->db->select('*')
                        ->from('news')
                          ->where('active', true)
                            ->limit(1)
                              ->order_by('id', 'DESC')
                                ->get()->row();
    return $query->id;
  }

#============ Pagination ================
  function get_pagination_result( $page,$size )
  {
    $start = ( $page - 1 ) * $size; /* a partir de q producto hay que mostrar */
    $this->db->select('*')
                ->from('news')
                  ->where('news.active', true)
                      ->order_by('id', 'DESC')
                        ->limit( $size , $start );

    return $this->db->get()->result();
  }

  function cant_paginas()
  {
    $novedades_por_pag = 9;
    $cantidad_novedades = $this->db->get_where('news',
                                        array('active' => true))->num_rows();

    if (is_float($cantidad_novedades / $novedades_por_pag)) {
      $cantidad_paginas = intval($cantidad_novedades / $novedades_por_pag) + 1;
    } else {
      $cantidad_paginas = intval($cantidad_novedades / $novedades_por_pag);
    }
    return  $cantidad_paginas;
  }

  function count_result($table, $attr, $value_attr)
  {
    $query = $this->db->get_where($table, array($attr => $value_attr));
    return $query->num_rows();
  }

}
