<?php

class Newsletter_model extends CI_Model {

  public $table = 'newsletters';

  function __construct()
  {
    parent::__construct();
  }

  function get($attr = null, $valor = null)
  {
  	if($attr != null and $valor != null) {
  		$query = $this->db->select('*')
                          ->from($this->table)
                            ->where($this->table.'.'.$attr, $valor)
                              ->get();
      return $query->result();
  	} else {
    		return $this->db->select('*')->from($this->table)->get()->result();
    	}
  }

  function insert_entry( $entry )
  {
  	return $this->db->insert( $this->table, $entry );
  }

  function update_entry($id, $entry)
  {
    $this->db->where('id', $id);
    return $this->db->update($this->table, $entry);
  }

  function destroy( $id )
  {
    $entry = $this->db->get_where($this->table, array('id' => $id))->row();
    $entry->active = false;

    $this->db->where('id', $id);
    return $this->db->update($this->table, $entry);
  }

  function get_last_id()
  {
    $query = $this->db->select('*')
                        ->from($this->table)
                          ->where('active', true)
                            ->limit(1)
                              ->order_by('id', 'DESC')
                                ->get()->row();
    return $query->id;
  }

  function validate_name( $name )
  {
    $query = $this->db->get_where($this->table, array('name' => $name));
    return ( $query->num_rows() );
  }

  function change_active( $id )
  {
    $entry = $this->db->get_where($this->table, array('id' => $id))->row();
    $entry->active = !$entry->active;

    $this->db->where('id', $id);
    return $this->db->update($this->table, $entry);
  }

}
