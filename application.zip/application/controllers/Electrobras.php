<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Electrobras extends CI_Controller {

	function __construct()
	{
	  parent::__construct();
	  date_default_timezone_set('America/Argentina/Buenos_Aires');
	}

	public function index()
	{
		$menu['is_active'] = array( 'inicio' => 'active', 'productos' => '', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('layouts/slider');
		$this->load->view('pages/home/home2');
		$this->load->view('layouts/footer');
	}

	function empresa()
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => '', 'contacto' => '', 'empresa' => 'active', 'newsletter' => '' );
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('layouts/slider');
		$this->load->view('pages/home/empresa');
		$this->load->view('layouts/footer');
	}

	public function home2()
	{
		$menu['is_active'] = array( 'inicio' => 'active', 'productos' => '', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('layouts/slider');
		$this->load->view('pages/home/home2');
		$this->load->view('layouts/footer');
	}

	public function home3()
	{
		$menu['is_active'] = array( 'inicio' => 'active', 'productos' => '', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar',$menu);
		$this->load->view('layouts/slider');
		$this->load->view('pages/home/home3');
		$this->load->view('layouts/footer');
	}

	public function contacto()
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => '', 'contacto' => 'active', 'empresa' => '', 'newsletter' => '' );
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar',$menu);
		$this->load->view('pages/home/contactos');
		$this->load->view('layouts/footer');
	}

		public function imagenes()
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => 'active', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$data['imagenes'] = array(
				
'ilum1.jpg',
'ilum2.jpg',
'ilum3.jpg',
'ilum4.jpg',
'ilum5.jpg',
'ilum6.jpg',
'ilum7.jpg',
'ilum8.jpg',
'ilum9.jpg',
'ilum10.jpg',
'ilum11.jpg',
'ilum12.jpg',
'ilum13.jpg',
'ilum14.jpg',
'ilum15.jpg',
'inter1.jpg',
'inter2.jpg',
'inter3.jpg',
'inter4.jpg',
'inter5.jpg',
'inter6.jpg',
'inter7.jpg',
'inter8.jpg',
'inter9.jpg',
'inter10.jpg',
'mueb1.jpg',
'mueb2.jpg',
'mueb3.jpg',
'mueb4.jpg',
'mueb5.jpg',
'mueb6.jpg',
'mueb7.jpg',
'mueb8.jpg',
'mueb10.jpg',
'mueb11.jpg',
'segu1.jpg',
'segu2.jpg',
'segu3.jpg',
'segu4.jpg',
'segu5.jpg',
'segu6.jpg',
'segu7.jpg',
'segu8.jpg',
'segu9.jpg',
'segu10.jpg',
			);
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar',$menu);
		$this->load->view('layouts/slider');
		$this->load->view('pages/home/imagenes', $data);
		$this->load->view('layouts/footer');
	}
    
    public function Iluminacion()
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => 'active', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$data['iluminacion'] = array(
				'1.jpg','2.jpg','3.jpg','4.jpg','5.jpg','6.jpg','7.jpg','8.jpg','9.jpg','10.jpg','11.jpg','12.jpg','13.jpg','14.jpg','15.jpg','16.jpg','17.jpg','18.jpg','19.jpg','20.jpg','21.jpg','22.jpg','23.jpg','24.jpg','25.jpg','26.jpg','27.jpg','28.jpg','29.jpg','30.jpg','31.jpg','32.jpg','33.jpg','34.jpg','35.jpg','36.jpg','37.jpg','38.jpg','39.jpg','40.jpg'
			);
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar',$menu);
	#	$this->load->view('layouts/slider');
		$this->load->view('pages/home/iluminacion', $data);
		$this->load->view('layouts/footer');
	}

	public function Electricidad()
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => 'active', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$data['electricidad'] = array(
				'1.jpg','2.jpg','3.jpg','4.jpg','5.jpg','6.jpg','7.jpg','8.jpg','9.jpg','10.jpg','11.jpg','12.jpg','13.jpg','14.jpg','15.jpg','16.jpg','17.jpg','18.jpg','19.jpg','20.jpg','21.jpg','22.jpg','23.jpg','24.jpg','25.jpg','26.jpg','27.jpg','28.jpg','29.jpg','30.jpg','31.jpg','32.jpg','33.jpg','34.jpg','35.jpg'
			);
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar',$menu);
	#	$this->load->view('layouts/slider');
		$this->load->view('pages/home/electricidad', $data);
		$this->load->view('layouts/footer');
	}
	
		function send_mail( )
	{
		$info = array(
			'nombre' => $_POST['nombre'],
			'email' => $_POST['email'],
			'asunto' => $_POST['asunto'],
			'mensaje' => $_POST['mensaje'],
			'telefono' => $_POST['telefono']
		);
		$this->load->library('email');
		$config = array(
				'protocol' 	=> 'smtp',
				'mailpath' 	=> '/usr/sbin/sendmail',
				'charset'  	=> 'utf-8',
				'wordwrap' 	=> TRUE,
				'smtp_host' => 'mail.electrobrassrl.com.ar',
				'smtp_user' => 'correo@electrobrassrl.com.ar',
				'smtp_pass' => 'password',
				'smtp_port' => 587,
				'mailtype'	=> 'html'
			);
		$data['data'] = $info;
		$message = $this->load->view('pages/emails/contacto', $data, TRUE);
		$this->email->initialize($config);
    $this->email
          ->from($_POST['email'])
          ->to( 'correo@electrobrassrl.com.ar' ) 
          ->subject( $_POST['asunto'] )
          ->message( $message )
          ->send( );

	  redirect('Electrobras');
	}
}
