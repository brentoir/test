<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Galeria extends CI_Controller {

	function __construct()
	{
	  parent::__construct();
	  $this->load->model('Category_model');
	  $this->load->model('Galery_model');
	  date_default_timezone_set('America/Argentina/Buenos_Aires');
	}

	function index( $pagina = 1 )
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => 'active', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$data['categories'] = $this->Category_model->get();
		$data['images'] = $this->set_data_images();
		// $data['cantidad_paginas'] = $this->Galery_model->cant_paginas();
		// $data['pagina_actual'] = $pagina;
		// $data['pagina_anterior'] = ($pagina == 1) ? null : $pagina - 1;
		// $data['pagina_siguiente'] = ($pagina == $data['cantidad_paginas']) ? null : $pagina + 1;
		// $data['news'] = $this->Galery_model->get_pagination_result( $pagina , 9 );

		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/galery/galery',$data);
		$this->load->view('layouts/footer');
	}

	function new($error_imagen = null)
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => 'active', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$data['error_imagen'] = $error_imagen;
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/galery/new', $data);
		$this->load->view('layouts/footer');
	}

	function create()
	{
		$number = $this->Galery_model->get_last_id() + 1;
		$url = '/srv/http/electrobras';
   	$config['upload_path'] = $url.'/assets/img/galery/';
    $config['allowed_types'] = 'jpg|png|jpeg';
    $config['file_name'] = 'galery_'.$number;
    $config['max_size'] = '2000';
    $config['max_width'] = '2024';
    $config['max_height'] = '2008';
    $this->load->library('upload', $config);

    if (!$this->upload->do_upload('imagefile')) {
        // $error = array('error' => $this->upload->display_errors());
        // redirect('Novedades/new', $error);
    		echo $this->upload->display_errors();
    	}else{
		    $image = array(
					'path' => $this->upload->data('file_name'),
					'created_at' => date('Y-m-d'),
					'active' => true,
					'categories' => strtolower($_POST['categories_image']),
				);
				if($this->Galery_model->insert_entry($image)){
					redirect('Galeria');
				} else {
					redirect('Galeria/New_image');
				}
    	}
	}

	function edit( $id, $error_imagen = null )
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => 'active', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => '' );
		$image = $this->Galery_model->get('id', $id);
		$data['image'] = $image[0];
		$data['error_imagen'] = $error_imagen;
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/galery/edit', $data);
		$this->load->view('layouts/footer');
	}

	function update()
	{
		if ( !empty( $_FILES['imagefile']['name'] ) ) {
			$url = '/srv/http/electrobras';
	   	$config['upload_path'] = $url.'/assets/img/galery/';
	    $config['allowed_types'] = 'jpg|png|jpeg';
	    $config['overwrite'] = true;
	    $config['file_name'] = 'galery_'.$_POST['image_id'];
	    $config['max_size'] = '2000';
	    $config['max_width'] = '2024';
	    $config['max_height'] = '2008';
	    $this->load->library('upload', $config);

			if (!$this->upload->do_upload('imagefile')) {
	      $error = array('error' => $this->upload->display_errors());
	      // redirect('Novedades/edit', $_POST['new_id'], $error);
	      echo $error;
	  	} else {
					$image = array(
						'path' => $this->upload->data('file_name'),
						'created_at' => date('Y-m-d'),
						'active' => true,
						'categories' => strtolower($_POST['categories_image']),
					);
					if($this->Galery_model->update_entry( $_POST['image_id'],$new )){

						redirect('Galeria');
					} else {
						// redirect('Novedades/edit', $_POST['new_id']);
						echo "error al editar datos";
					}
	  	}
		} else {
		  		$image = array(
						'categories' => strtolower($_POST['categories_image']),
					);
					if($this->Galery_model->update_entry( $_POST['image_id'],$image )){
						redirect('Galeria');
					} else {
						// redirect('Novedades/edit', $_POST['new_id']);
						echo "error al editar datos";
					}
		}
	}

	function destroy()
	{
		if ( $this->Galery_model->destroy( $_POST['id'] ) ) {
			echo 'ok';
		} else {
			echo 'false';
		}
	}

	function set_data_images()
	{
		$data = $this->Galery_model->get();
		foreach ($data as $d) {
			$d->categories = str_replace(',', ' ', $d->categories);
			$d->categories = strtolower($d->categories);
		}
		return $data;
	}

	function get_categories()
	{
		$categories = $this->Category_model->get();
		echo json_encode( $categories );
	}

	function ajax_list_categories()
	{
		$query = $this->Category_model->get();
		$data = array();

		foreach ($query as $q) {
			$row = array();

			$row[] = $q->name;

			$row[] = '<button class="disabled btn btn-sm u-btn-primary g-mr-4 g-mb-4" title="Editar" onclick="edit_category('."'".$q->id."'".')" >
									<i class="fa fa-edit"></i>
								</button>
								<button class="btn btn-sm u-btn-red g-mr-5 g-mb-5" title="Eliminar" 
									onclick="modal_delete_category('. $q->id .')" >
									<i class="fa fa-trash-o"></i>
								</button>';
			$data[] = $row;
		}

		$output = array("data" => $data);
		echo json_encode($output);
	}

	function create_category()
	{
		$entry = array( 
			'name' => $_POST['name'],
			'created_at' => date('Y-m-d'),
			'active' => 1
		);
		if ( $this->Category_model->insert_entry( $entry ) ) {
			echo 'success';
		} else {
			echo 'error';
		}
	}

	function destroy_category()
	{
		if ( $this->Category_model->destroy( $_POST['id'] ) ) {
			echo 'ok';
		} else {
			echo 'false';
		}
	}
	function validate_category_name()
	{
		/* Nombre debe ser unico */ 
    $name = $_POST['name'];
    if ( $this->Category_model->validate_name( $name ) != 0 ) {
      echo 'false';
    } else {
      echo 'true';
    }
  }

}


