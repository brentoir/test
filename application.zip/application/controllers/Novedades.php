<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Novedades extends CI_Controller {

	function __construct()
	{
	  parent::__construct();
	  $this->load->model('New_model');
	  date_default_timezone_set('America/Argentina/Buenos_Aires');
	}

	function index( $pagina = 1 )
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => 'active', 'contacto' => '', 'empresa' => '', 'newsletter' => ''  );
		$data['cantidad_paginas'] = $this->New_model->cant_paginas();
		$data['pagina_actual'] = $pagina;
		$data['pagina_anterior'] = ($pagina == 1) ? null : $pagina - 1;
		$data['pagina_siguiente'] = ($pagina == $data['cantidad_paginas']) ? null : $pagina + 1;
		$data['news'] = $this->New_model->get_pagination_result( $pagina , 9 );

		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/news/index', $data);
		$this->load->view('layouts/footer');
	}

	function admin()
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => 'active', 'contacto' => '', 'empresa' => '', 'newsletter' => ''  );
		$data['news'] = $this->New_model->get();
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/news/admin', $data);
		$this->load->view('layouts/footer');
	}

	function new($error_imagen = null)
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => 'active', 'contacto' => '', 'empresa' => '', 'newsletter' => ''  );
		$data['error_imagen'] = $error_imagen;
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/news/new', $data);
		$this->load->view('layouts/footer');
	}

	function create()
	{
		$number = $this->New_model->get_last_id() + 1;
		$url = '/srv/http/electrobras';
       	$config['upload_path'] = $url.'/assets/img/novedades/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['file_name'] = 'nov_'.$number;
        $config['max_size'] = '2000';
        $config['max_width'] = '2024';
        $config['max_height'] = '2008';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('imagefile')) {
            // $error = array('error' => $this->upload->display_errors());
            // redirect('Novedades/new', $error);
        		echo $this->upload->display_errors();
        	}else{
				    $new = array(
							'title' => $_POST['title'],
							'content' => $_POST['content'],
							'image_name' => $this->upload->data('file_name'),
							'created_at' => date('Y-m-d'),
							'active' => true
						);
						if($this->New_model->insert_entry($new)){
							redirect('Novedades');
						} else {
							redirect('Novedades/new');
						}
        	}
	}

	function edit( $id, $error_imagen = null )
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => 'active', 'contacto' => '', 'empresa' => '', 'newsletter' => ''  );
		$new = $this->New_model->get('id', $id);
		$data['new'] = $new[0];
		$data['error_imagen'] = $error_imagen;
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/news/edit', $data);
		$this->load->view('layouts/footer');
	}

	function update()
	{
		$seguir_edicion = false; /* la idea es que si existe img se verifique la subida, si no existe habria que seguir la edicion sin problemas */
		if ( !empty( $_FILES['imagefile']['name'] ) ) {
			$url = '/srv/http/electrobras';
	   	$config['upload_path'] = $url.'/assets/img/novedades/';
	    $config['allowed_types'] = 'jpg|png|jpeg';
	    $config['overwrite'] = true;
	    $config['file_name'] = 'nov_'.$_POST['new_id'];
	    $config['max_size'] = '2000';
	    $config['max_width'] = '2024';
	    $config['max_height'] = '2008';
	    $this->load->library('upload', $config);

			if (!$this->upload->do_upload('imagefile')) {
	      $error = array('error' => $this->upload->display_errors());
	      // redirect('Novedades/edit', $_POST['new_id'], $error);
	      echo $error;
	  	} else {
	  		$new = array(
						'title' => $_POST['title'],
						'content' => $_POST['content'],
						'created_at' => date('Y-m-d')
					);
					if($this->New_model->update_entry( $_POST['new_id'],$new )){
						echo "true insert entry";

						redirect('Novedades/admin');
					} else {
						// redirect('Novedades/edit', $_POST['new_id']);
						echo "error al editar datos";
					}
	  	}
		} else {
	  		$new = array(
						'title' => $_POST['title'],
						'content' => $_POST['content'],
						'created_at' => date('Y-m-d')
					);
					if($this->New_model->update_entry( $_POST['new_id'],$new )){
						echo "true insert entry";

						redirect('Novedades/admin');
					} else {
						// redirect('Novedades/edit', $_POST['new_id']);
						echo "error al editar datos";
					}
		}
	}

	function destroy()
	{
		if ( $this->New_model->destroy( $_POST['id'] ) ) {
			echo 'ok';
		} else {
			echo 'false';
		}
	}
}


