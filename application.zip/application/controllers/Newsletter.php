<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Newsletter extends CI_Controller {

	function __construct()
	{
	  parent::__construct();
	  $this->load->model('Newsletter_model');
	  $this->load->model('Email_list_model');
	  date_default_timezone_set('America/Argentina/Buenos_Aires');
	}

	function index( $pagina = 1 )
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => 'active'  );

		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/newsletter/index');
		$this->load->view('layouts/footer');
	}

	function new($error_imagen = null)
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => 'active'  );
		$data['error_imagen'] = $error_imagen;
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/newsletter/new', $data);
		$this->load->view('layouts/footer');
	}

	function create()
	{
		$number = $this->Newsletter_model->get_last_id() + 1;
		$url = '/srv/http/electrobras';
       	$config['upload_path'] = $url.'/assets/img/newsletters/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['file_name'] = 'newsletter_'.$number;
        $config['max_size'] = '5000';
        $config['max_width'] = '2024';
        $config['max_height'] = '2008';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('imagefile')) {
            // $error = array('error' => $this->upload->display_errors());
            // redirect('Newsletter/new', $error);
        		echo $this->upload->display_errors();
        	}else{
				    $newsletter = array(
							'subject' => $_POST['subject'],
							'message' => $_POST['message'],
							'img' => $this->upload->data('file_name'),
							'created_at' => date('Y-m-d H:i:s'),
							'active' => true
						);
						if($this->Newsletter_model->insert_entry($newsletter)){
							$this->send_mail( $number );
							redirect('Newsletter');
						} else {
							redirect('Newsletter/new');
						}
        	}
	}

	function edit( $id, $error_imagen = null )
	{
		$menu['is_active'] = array( 'inicio' => '', 'productos' => '', 'novedades' => '', 'contacto' => '', 'empresa' => '', 'newsletter' => 'active'  );
		$new = $this->Newsletter_model->get('id', $id);
		$data['new'] = $new[0];
		$data['error_imagen'] = $error_imagen;
		$this->load->view('layouts/head');
		$this->load->view('layouts/navbar', $menu);
		$this->load->view('pages/newsletter/edit', $data);
		$this->load->view('layouts/footer');
	}

	function update()
	{
		$seguir_edicion = false; /* la idea es que si existe img se verifique la subida, si no existe habria que seguir la edicion sin problemas */
		if ( !empty( $_FILES['imagefile']['name'] ) ) {
			$url = '/srv/http/electrobras';
	   	$config['upload_path'] = $url.'/assets/img/newsletter/';
	    $config['allowed_types'] = 'jpg|png|jpeg';
	    $config['overwrite'] = true;
	    $config['file_name'] = 'newsletter_'.$_POST['new_id'];
	    $config['max_size'] = '2000';
	    $config['max_width'] = '2024';
	    $config['max_height'] = '2008';
	    $this->load->library('upload', $config);

			if (!$this->upload->do_upload('imagefile')) {
	      $error = array('error' => $this->upload->display_errors());
	      // redirect('Newsletter/edit', $_POST['new_id'], $error);
	      echo $error;
	  	} else {
	  		$new = array(
						'title' => $_POST['title'],
						'content' => $_POST['content'],
						'created_at' => date('Y-m-d')
					);
					if($this->Newsletter_model->update_entry( $_POST['new_id'],$new )){
						echo "true insert entry";

						redirect('Newsletter/admin');
					} else {
						// redirect('Newsletter/edit', $_POST['new_id']);
						echo "error al editar datos";
					}
	  	}
		} else {
	  		$new = array(
						'title' => $_POST['title'],
						'content' => $_POST['content'],
						'created_at' => date('Y-m-d')
					);
					if($this->Newsletter_model->update_entry( $_POST['new_id'],$new )){
						echo "true insert entry";

						redirect('Newsletter/admin');
					} else {
						// redirect('Newsletter/edit', $_POST['new_id']);
						echo "error al editar datos";
					}
		}
	}

	function destroy()
	{
		if ( $this->Newsletter_model->destroy( $_POST['id'] ) ) {
			echo 'ok';
		} else {
			echo 'false';
		}
	}

	function ajax_list_emails()
	{
		$query = $this->Email_list_model->get();
		$data = array();

		foreach ($query as $q) {
			$row = array();

			$row[] = $q->name;
			$row[] = $q->email;
			if ( $q->active ) {
				$row[] = '<button class="btn btn-sm u-btn-primary g-mr-4 g-mb-4" title="Editar" onclick="change_active('."'".$q->id."'".')" >
									<i class="fa fa-check"></i> Autorizado
								</button>';
			} else {
				$row[] = '<button class="btn btn-sm u-btn-red g-mr-4 g-mb-4" title="Editar" onclick="change_active('."'".$q->id."'".')" >
									<i class="fa fa-remove"></i> Sin autorizar
								</button>';
			}
			$row[] = '<button class="disabled btn btn-sm u-btn-primary g-mr-4 g-mb-4" title="Editar" onclick="edit_category('."'".$q->id."'".')" >
									<i class="fa fa-edit"></i>
								</button>
								<button class="btn btn-sm u-btn-red g-mr-5 g-mb-5" title="Eliminar" 
									onclick="modal_delete('. $q->id .')" >
									<i class="fa fa-trash-o"></i>
								</button>';
			$data[] = $row;
		}

		$output = array("data" => $data);
		echo json_encode($output);
	}

	function change_active()
	{
		/* Activa o desactiva los mails autorizados para enviar correos */
		if ( $this->Email_list_model->change_active( $_POST['id'] ) ) {
			echo 'ok';
		} else {
			echo 'error';
		}
	}

	function send_mail( $newsletter_id )
	{
		$email_list = $this->array_emails();
		$info_newsletter = $this->Newsletter_model->get('id', $newsletter_id );
		$this->load->library('email');
		$config = array(
				'protocol' 	=> 'smtp',
				'mailpath' 	=> '/usr/sbin/sendmail',
				'charset'  	=> 'utf-8',
				'wordwrap' 	=> TRUE,
				'smtp_host' => 'mail.maurosampaoli.com.ar',
				'smtp_user' => 'web@maurosampaoli.com.ar',
				'smtp_pass' => 'web1A3B55',
				'smtp_port' => 587,
				'mailtype'	=> 'html'
			);
		$data['data'] = $info_newsletter[0];
		$message = $this->load->view('pages/newsletter/email', $data, TRUE);
		$this->email->initialize($config);
    $this->email
          ->from('web@maurosampaoli.com.ar')
          ->to( $email_list )
          ->subject( $info_newsletter[0]->subject )
          ->message( $message )
          ->send();

	  echo $this->email->print_debugger();
	}

	function check_email( )
	{
		// Verificamos que el email no exista
		$email = $this->Email_list_model->get( 'email', $_POST['email'] );
		if ( count($email) > 0 ) {
				echo 'false';
			} else {
				echo 'disponible';
			}
	}

	function new_email()
	{
		$entry = array( 
							'name' => $_POST['name'], 
							'email' => $_POST['email'],
							'created_at' => date('Y-m-d') );
		if ($this->Email_list_model->insert_entry( $entry )) {
			echo 'success';
		} else {
			echo 'error';
		}
	}

}


